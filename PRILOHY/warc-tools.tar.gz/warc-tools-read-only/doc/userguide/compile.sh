rm -f *~
jw manwarc.sgml -p /usr/bin/openjade -b pdf 

