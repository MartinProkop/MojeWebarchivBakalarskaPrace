/**
 * 
 */
package org.jhove2.module.format.tiff.type;

import org.jhove2.core.reportable.AbstractReportable;

import com.sleepycat.persist.model.Persistent;

/**
 * @author mstrong
 *
 */
@Persistent
public class RationalArray
    extends AbstractReportable {
    
    /**  no-arg constructor for RationalArray object */
    public RationalArray() {
    }

}

