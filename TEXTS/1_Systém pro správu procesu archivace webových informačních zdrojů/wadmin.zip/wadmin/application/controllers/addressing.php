<?php
class Addressing_Controller extends Template_Controller {
	
	protected $title = 'Oslovování';
	
	public function index() {
		
	}
}
?>