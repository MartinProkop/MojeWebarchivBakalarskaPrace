<?php
class Rate_Controller extends Template_Controller {
	
	protected $title = 'Hodnocení zdrojů';
	
	public function index() {

	}
}
?>