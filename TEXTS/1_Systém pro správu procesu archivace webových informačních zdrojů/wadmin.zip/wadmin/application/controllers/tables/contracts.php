<?php
class Contracts_Controller extends Table_Controller {
	protected $table = 'contract';
	protected $title = 'Contracts';
}
?>