<?php
class Resources_Controller extends Table_Controller {
	protected $table = 'resource';
	protected $title = 'Resources';
}
?>