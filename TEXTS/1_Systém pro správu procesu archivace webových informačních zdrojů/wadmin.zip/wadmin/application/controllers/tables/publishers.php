<?php
class Publishers_Controller extends Table_Controller {
	protected $table = 'publisher';
	protected $title = 'Publishers';
}
?>