<?php
class Progress_Controller extends Template_Controller {
	
	protected $title = 'V jednání';
	
	public function index() {
		
	}
}
?>