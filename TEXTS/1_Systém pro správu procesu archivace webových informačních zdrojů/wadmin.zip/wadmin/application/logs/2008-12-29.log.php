<?php defined('SYSPATH') or die('No direct script access.'); ?>

2008-12-29 11:26:53 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-29 11:26:53 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-29 11:26:53 +01:00 --- debug: Profiler Library initialized
2008-12-29 11:26:53 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-29 11:26:53 +01:00 --- debug: Database Library initialized
