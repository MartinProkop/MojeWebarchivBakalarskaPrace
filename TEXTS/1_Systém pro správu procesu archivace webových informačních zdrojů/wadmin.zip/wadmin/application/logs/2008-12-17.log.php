<?php defined('SYSPATH') or die('No direct script access.'); ?>

2008-12-17 11:26:15 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 11:26:15 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 11:26:15 +01:00 --- debug: Profiler Library initialized
2008-12-17 11:26:15 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 11:26:15 +01:00 --- debug: Database Library initialized
2008-12-17 11:30:03 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 11:30:03 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 11:30:03 +01:00 --- debug: Profiler Library initialized
2008-12-17 11:30:03 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 11:30:03 +01:00 --- debug: Database Library initialized
2008-12-17 11:33:41 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 11:33:41 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 11:33:41 +01:00 --- debug: Profiler Library initialized
2008-12-17 11:33:41 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 11:33:41 +01:00 --- debug: Database Library initialized
2008-12-17 11:34:52 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 11:34:52 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 11:34:52 +01:00 --- debug: Profiler Library initialized
2008-12-17 11:34:52 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 11:34:52 +01:00 --- debug: Database Library initialized
2008-12-17 11:38:32 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 11:38:32 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 11:38:32 +01:00 --- debug: Profiler Library initialized
2008-12-17 11:38:32 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 11:38:32 +01:00 --- debug: Database Library initialized
2008-12-17 11:38:45 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 11:38:45 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 11:38:45 +01:00 --- debug: Profiler Library initialized
2008-12-17 11:38:45 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 11:38:45 +01:00 --- debug: Database Library initialized
2008-12-17 11:39:52 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 11:39:52 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 11:39:52 +01:00 --- debug: Profiler Library initialized
2008-12-17 11:39:52 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 11:39:52 +01:00 --- debug: Database Library initialized
2008-12-17 11:47:25 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 11:47:25 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 11:47:25 +01:00 --- debug: Profiler Library initialized
2008-12-17 11:48:17 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 11:48:17 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 11:48:17 +01:00 --- debug: Profiler Library initialized
2008-12-17 11:48:17 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 11:48:17 +01:00 --- debug: Database Library initialized
2008-12-17 11:48:26 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 11:48:26 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 11:48:26 +01:00 --- debug: Profiler Library initialized
2008-12-17 11:48:26 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 11:48:26 +01:00 --- debug: Database Library initialized
2008-12-17 12:07:28 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 12:07:28 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 12:07:28 +01:00 --- debug: Profiler Library initialized
2008-12-17 12:07:28 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 12:07:28 +01:00 --- debug: Database Library initialized
2008-12-17 12:08:16 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 12:08:16 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 12:08:16 +01:00 --- debug: Profiler Library initialized
2008-12-17 12:08:16 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 12:08:16 +01:00 --- debug: Database Library initialized
2008-12-17 12:10:10 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 12:10:10 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 12:10:10 +01:00 --- debug: Profiler Library initialized
2008-12-17 12:10:10 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 12:10:10 +01:00 --- debug: Database Library initialized
2008-12-17 12:13:17 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 12:13:17 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 12:13:17 +01:00 --- debug: Profiler Library initialized
2008-12-17 12:13:17 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 12:13:17 +01:00 --- debug: Database Library initialized
2008-12-17 12:13:46 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 12:13:46 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 12:13:46 +01:00 --- debug: Profiler Library initialized
2008-12-17 12:13:46 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 12:13:46 +01:00 --- debug: Database Library initialized
2008-12-17 12:14:31 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 12:14:31 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 12:14:31 +01:00 --- debug: Profiler Library initialized
2008-12-17 12:14:31 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 12:14:31 +01:00 --- debug: Database Library initialized
2008-12-17 12:15:48 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 12:15:48 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 12:15:48 +01:00 --- debug: Profiler Library initialized
2008-12-17 12:15:51 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 12:15:51 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 12:15:51 +01:00 --- debug: Profiler Library initialized
2008-12-17 12:15:51 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 12:15:51 +01:00 --- debug: Database Library initialized
2008-12-17 12:16:10 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 12:16:10 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 12:16:10 +01:00 --- debug: Profiler Library initialized
2008-12-17 12:16:10 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 12:16:10 +01:00 --- debug: Database Library initialized
2008-12-17 12:16:36 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 12:16:36 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 12:16:36 +01:00 --- debug: Profiler Library initialized
2008-12-17 12:16:36 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 12:16:36 +01:00 --- debug: Database Library initialized
2008-12-17 12:16:51 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 12:16:51 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 12:16:51 +01:00 --- debug: Profiler Library initialized
2008-12-17 12:16:52 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 12:16:52 +01:00 --- debug: Database Library initialized
2008-12-17 12:17:00 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 12:17:00 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 12:17:00 +01:00 --- debug: Profiler Library initialized
2008-12-17 12:17:00 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 12:17:00 +01:00 --- debug: Database Library initialized
2008-12-17 12:17:11 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 12:17:11 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 12:17:11 +01:00 --- debug: Profiler Library initialized
2008-12-17 12:17:11 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 12:17:11 +01:00 --- debug: Database Library initialized
2008-12-17 12:18:57 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 12:18:57 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 12:18:57 +01:00 --- debug: Profiler Library initialized
2008-12-17 12:18:57 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 12:18:57 +01:00 --- debug: Database Library initialized
2008-12-17 12:19:45 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 12:19:45 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 12:19:45 +01:00 --- debug: Profiler Library initialized
2008-12-17 12:19:45 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 12:19:45 +01:00 --- debug: Database Library initialized
2008-12-17 12:19:46 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 12:19:46 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 12:19:46 +01:00 --- debug: Profiler Library initialized
2008-12-17 12:19:46 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 12:19:46 +01:00 --- debug: Database Library initialized
2008-12-17 12:19:46 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 12:19:46 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 12:19:46 +01:00 --- debug: Profiler Library initialized
2008-12-17 12:19:46 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 12:19:46 +01:00 --- debug: Database Library initialized
2008-12-17 12:20:01 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 12:20:01 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 12:20:01 +01:00 --- debug: Profiler Library initialized
2008-12-17 12:20:01 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 12:20:01 +01:00 --- debug: Database Library initialized
2008-12-17 12:20:18 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 12:20:18 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 12:20:18 +01:00 --- debug: Profiler Library initialized
2008-12-17 12:20:18 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 12:20:18 +01:00 --- debug: Database Library initialized
2008-12-17 12:29:01 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 12:29:01 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 12:29:01 +01:00 --- debug: Profiler Library initialized
2008-12-17 12:29:01 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 12:29:01 +01:00 --- debug: Database Library initialized
2008-12-17 12:29:18 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 12:29:18 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 12:29:18 +01:00 --- debug: Profiler Library initialized
2008-12-17 12:29:18 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 12:29:18 +01:00 --- debug: Database Library initialized
2008-12-17 12:32:10 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 12:32:10 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 12:32:10 +01:00 --- debug: Profiler Library initialized
2008-12-17 12:32:10 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 12:32:10 +01:00 --- debug: Database Library initialized
2008-12-17 12:33:37 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 12:33:37 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 12:33:37 +01:00 --- debug: Profiler Library initialized
2008-12-17 12:33:37 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 12:33:37 +01:00 --- debug: Database Library initialized
2008-12-17 12:34:01 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 12:34:01 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 12:34:01 +01:00 --- debug: Profiler Library initialized
2008-12-17 12:34:01 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 12:34:01 +01:00 --- debug: Database Library initialized
2008-12-17 12:34:45 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 12:34:45 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 12:34:45 +01:00 --- debug: Profiler Library initialized
2008-12-17 12:34:45 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 12:34:45 +01:00 --- debug: Database Library initialized
2008-12-17 12:36:25 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 12:36:25 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 12:36:25 +01:00 --- debug: Profiler Library initialized
2008-12-17 12:36:25 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 12:36:25 +01:00 --- debug: Database Library initialized
2008-12-17 12:37:00 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 12:37:00 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 12:37:00 +01:00 --- debug: Profiler Library initialized
2008-12-17 12:37:00 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 12:37:00 +01:00 --- debug: Database Library initialized
2008-12-17 12:38:22 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 12:38:22 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 12:38:22 +01:00 --- debug: Profiler Library initialized
2008-12-17 12:38:22 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 12:38:22 +01:00 --- debug: Database Library initialized
2008-12-17 12:40:29 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 12:40:29 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 12:40:29 +01:00 --- debug: Profiler Library initialized
2008-12-17 12:40:29 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 12:40:29 +01:00 --- debug: Database Library initialized
2008-12-17 12:41:25 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 12:41:25 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 12:41:25 +01:00 --- debug: Profiler Library initialized
2008-12-17 12:41:25 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 12:41:25 +01:00 --- debug: Database Library initialized
2008-12-17 12:43:14 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 12:43:14 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 12:43:14 +01:00 --- debug: Profiler Library initialized
2008-12-17 12:43:14 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 12:43:14 +01:00 --- debug: Database Library initialized
2008-12-17 12:45:00 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 12:45:00 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 12:45:00 +01:00 --- debug: Profiler Library initialized
2008-12-17 12:45:00 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 12:45:00 +01:00 --- debug: Database Library initialized
2008-12-17 12:52:42 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 12:52:42 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 12:52:42 +01:00 --- debug: Profiler Library initialized
2008-12-17 12:52:42 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 12:52:42 +01:00 --- debug: Database Library initialized
2008-12-17 12:56:56 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 12:56:56 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 12:56:56 +01:00 --- debug: Profiler Library initialized
2008-12-17 12:56:56 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 12:56:56 +01:00 --- debug: Database Library initialized
2008-12-17 12:57:06 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 12:57:06 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 12:57:06 +01:00 --- debug: Profiler Library initialized
2008-12-17 12:57:06 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 12:57:06 +01:00 --- debug: Database Library initialized
2008-12-17 12:57:30 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 12:57:30 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 12:57:30 +01:00 --- debug: Profiler Library initialized
2008-12-17 12:57:30 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 12:57:30 +01:00 --- debug: Database Library initialized
2008-12-17 13:02:57 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 13:02:57 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 13:02:57 +01:00 --- debug: Profiler Library initialized
2008-12-17 13:02:57 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 13:02:57 +01:00 --- debug: Database Library initialized
2008-12-17 13:03:19 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 13:03:19 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 13:03:19 +01:00 --- debug: Profiler Library initialized
2008-12-17 13:03:19 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 13:03:19 +01:00 --- debug: Database Library initialized
2008-12-17 13:06:18 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 13:06:18 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 13:06:18 +01:00 --- debug: Profiler Library initialized
2008-12-17 13:06:18 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 13:06:18 +01:00 --- debug: Database Library initialized
2008-12-17 13:06:50 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 13:06:50 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 13:06:50 +01:00 --- debug: Profiler Library initialized
2008-12-17 13:06:50 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 13:06:50 +01:00 --- debug: Database Library initialized
2008-12-17 13:08:18 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 13:08:18 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 13:08:18 +01:00 --- debug: Profiler Library initialized
2008-12-17 13:08:18 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 13:08:18 +01:00 --- debug: Database Library initialized
2008-12-17 13:08:21 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 13:08:21 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 13:08:21 +01:00 --- debug: Profiler Library initialized
2008-12-17 13:08:21 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 13:08:21 +01:00 --- debug: Database Library initialized
2008-12-17 13:09:13 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 13:09:13 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 13:09:13 +01:00 --- debug: Profiler Library initialized
2008-12-17 13:09:13 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 13:09:13 +01:00 --- debug: Database Library initialized
2008-12-17 13:09:25 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 13:09:25 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 13:09:25 +01:00 --- debug: Profiler Library initialized
2008-12-17 13:09:25 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 13:09:25 +01:00 --- debug: Database Library initialized
2008-12-17 15:13:30 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 15:13:30 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 15:13:30 +01:00 --- debug: Profiler Library initialized
2008-12-17 15:13:31 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 15:13:31 +01:00 --- debug: Database Library initialized
2008-12-17 15:15:19 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 15:15:19 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 15:15:19 +01:00 --- debug: Profiler Library initialized
2008-12-17 15:15:19 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 15:15:19 +01:00 --- debug: Database Library initialized
2008-12-17 15:17:37 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 15:17:37 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 15:17:37 +01:00 --- debug: Profiler Library initialized
2008-12-17 15:17:37 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 15:17:37 +01:00 --- debug: Database Library initialized
2008-12-17 15:18:20 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 15:18:20 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 15:18:20 +01:00 --- debug: Profiler Library initialized
2008-12-17 15:18:20 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 15:18:20 +01:00 --- debug: Database Library initialized
2008-12-17 15:19:10 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 15:19:10 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 15:19:10 +01:00 --- debug: Profiler Library initialized
2008-12-17 15:19:10 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 15:19:10 +01:00 --- debug: Database Library initialized
2008-12-17 15:19:32 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 15:19:32 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 15:19:32 +01:00 --- debug: Profiler Library initialized
2008-12-17 15:19:32 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 15:19:32 +01:00 --- debug: Database Library initialized
2008-12-17 15:20:28 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 15:20:28 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 15:20:28 +01:00 --- debug: Profiler Library initialized
2008-12-17 15:20:28 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 15:20:28 +01:00 --- debug: Database Library initialized
2008-12-17 15:21:07 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 15:21:07 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 15:21:07 +01:00 --- debug: Profiler Library initialized
2008-12-17 15:21:07 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 15:21:07 +01:00 --- debug: Database Library initialized
2008-12-17 15:21:39 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 15:21:39 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 15:21:39 +01:00 --- debug: Profiler Library initialized
2008-12-17 15:21:39 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 15:21:39 +01:00 --- debug: Database Library initialized
2008-12-17 15:22:10 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 15:22:10 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 15:22:10 +01:00 --- debug: Profiler Library initialized
2008-12-17 15:22:10 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 15:22:10 +01:00 --- debug: Database Library initialized
2008-12-17 15:24:05 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 15:24:05 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 15:24:05 +01:00 --- debug: Profiler Library initialized
2008-12-17 15:24:05 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 15:24:05 +01:00 --- debug: Database Library initialized
2008-12-17 15:24:38 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 15:24:38 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 15:24:38 +01:00 --- debug: Profiler Library initialized
2008-12-17 15:24:38 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 15:24:38 +01:00 --- debug: Database Library initialized
2008-12-17 15:26:50 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 15:26:50 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 15:26:50 +01:00 --- debug: Profiler Library initialized
2008-12-17 15:26:51 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 15:26:51 +01:00 --- debug: Database Library initialized
2008-12-17 15:29:40 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 15:29:40 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 15:29:40 +01:00 --- debug: Profiler Library initialized
2008-12-17 15:29:40 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 15:29:40 +01:00 --- debug: Database Library initialized
2008-12-17 15:29:50 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 15:29:50 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 15:29:50 +01:00 --- debug: Profiler Library initialized
2008-12-17 15:29:50 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 15:29:50 +01:00 --- debug: Database Library initialized
2008-12-17 15:30:08 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 15:30:08 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 15:30:08 +01:00 --- debug: Profiler Library initialized
2008-12-17 15:30:08 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 15:30:08 +01:00 --- debug: Database Library initialized
2008-12-17 15:30:20 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 15:30:20 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 15:30:20 +01:00 --- debug: Profiler Library initialized
2008-12-17 15:30:20 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 15:30:20 +01:00 --- debug: Database Library initialized
2008-12-17 15:31:17 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 15:31:17 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 15:31:17 +01:00 --- debug: Profiler Library initialized
2008-12-17 15:31:17 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 15:31:17 +01:00 --- debug: Database Library initialized
2008-12-17 15:32:07 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 15:32:07 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 15:32:07 +01:00 --- debug: Profiler Library initialized
2008-12-17 15:32:07 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 15:32:07 +01:00 --- debug: Database Library initialized
2008-12-17 15:32:35 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 15:32:35 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 15:32:35 +01:00 --- debug: Profiler Library initialized
2008-12-17 15:32:35 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 15:32:35 +01:00 --- debug: Database Library initialized
2008-12-17 15:33:20 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 15:33:20 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 15:33:20 +01:00 --- debug: Profiler Library initialized
2008-12-17 15:33:20 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 15:33:20 +01:00 --- debug: Database Library initialized
2008-12-17 15:33:50 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 15:33:50 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 15:33:50 +01:00 --- debug: Profiler Library initialized
2008-12-17 15:33:50 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 15:33:50 +01:00 --- debug: Database Library initialized
2008-12-17 15:34:11 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 15:34:11 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 15:34:11 +01:00 --- debug: Profiler Library initialized
2008-12-17 15:34:11 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 15:34:11 +01:00 --- debug: Database Library initialized
2008-12-17 15:34:50 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 15:34:50 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 15:34:50 +01:00 --- debug: Profiler Library initialized
2008-12-17 15:34:50 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 15:34:50 +01:00 --- debug: Database Library initialized
2008-12-17 15:35:14 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 15:35:14 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 15:35:14 +01:00 --- debug: Profiler Library initialized
2008-12-17 15:35:14 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 15:35:14 +01:00 --- debug: Database Library initialized
2008-12-17 15:36:52 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 15:36:52 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 15:36:52 +01:00 --- debug: Profiler Library initialized
2008-12-17 15:36:52 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 15:36:52 +01:00 --- debug: Database Library initialized
2008-12-17 15:37:22 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 15:37:22 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 15:37:22 +01:00 --- debug: Profiler Library initialized
2008-12-17 15:37:22 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 15:37:22 +01:00 --- debug: Database Library initialized
2008-12-17 15:38:06 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 15:38:06 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 15:38:06 +01:00 --- debug: Profiler Library initialized
2008-12-17 15:38:06 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 15:38:06 +01:00 --- debug: Database Library initialized
2008-12-17 15:38:31 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 15:38:31 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 15:38:31 +01:00 --- debug: Profiler Library initialized
2008-12-17 15:38:31 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 15:38:31 +01:00 --- debug: Database Library initialized
2008-12-17 15:47:03 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 15:47:03 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 15:47:03 +01:00 --- debug: Profiler Library initialized
2008-12-17 15:47:03 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 15:47:03 +01:00 --- debug: Database Library initialized
2008-12-17 15:47:35 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 15:47:35 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 15:47:35 +01:00 --- debug: Profiler Library initialized
2008-12-17 15:47:35 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 15:47:35 +01:00 --- debug: Database Library initialized
2008-12-17 15:49:21 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 15:49:21 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 15:49:21 +01:00 --- debug: Profiler Library initialized
2008-12-17 15:49:21 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 15:49:21 +01:00 --- debug: Database Library initialized
2008-12-17 15:49:24 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 15:49:24 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 15:49:24 +01:00 --- debug: Profiler Library initialized
2008-12-17 15:49:24 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 15:49:24 +01:00 --- debug: Database Library initialized
2008-12-17 15:50:19 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 15:50:19 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 15:50:19 +01:00 --- debug: Profiler Library initialized
2008-12-17 15:50:19 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 15:50:19 +01:00 --- debug: Database Library initialized
2008-12-17 15:50:29 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 15:50:29 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 15:50:29 +01:00 --- debug: Profiler Library initialized
2008-12-17 15:50:29 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 15:50:29 +01:00 --- debug: Database Library initialized
2008-12-17 15:51:12 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 15:51:12 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 15:51:12 +01:00 --- debug: Profiler Library initialized
2008-12-17 15:51:12 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 15:51:12 +01:00 --- debug: Database Library initialized
2008-12-17 15:51:21 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 15:51:21 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 15:51:21 +01:00 --- debug: Profiler Library initialized
2008-12-17 15:51:21 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 15:51:21 +01:00 --- debug: Database Library initialized
2008-12-17 15:51:33 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 15:51:33 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 15:51:33 +01:00 --- debug: Profiler Library initialized
2008-12-17 15:51:33 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 15:51:33 +01:00 --- debug: Database Library initialized
2008-12-17 15:51:41 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 15:51:41 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 15:51:41 +01:00 --- debug: Profiler Library initialized
2008-12-17 15:51:41 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 15:51:41 +01:00 --- debug: Database Library initialized
2008-12-17 15:52:10 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 15:52:10 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 15:52:10 +01:00 --- debug: Profiler Library initialized
2008-12-17 15:52:10 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 15:52:10 +01:00 --- debug: Database Library initialized
2008-12-17 15:52:11 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 15:52:11 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 15:52:11 +01:00 --- debug: Profiler Library initialized
2008-12-17 15:52:11 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 15:52:11 +01:00 --- debug: Database Library initialized
2008-12-17 15:52:41 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 15:52:41 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 15:52:41 +01:00 --- debug: Profiler Library initialized
2008-12-17 15:52:41 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 15:52:41 +01:00 --- debug: Database Library initialized
2008-12-17 15:53:02 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 15:53:02 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 15:53:02 +01:00 --- debug: Profiler Library initialized
2008-12-17 15:53:02 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 15:53:02 +01:00 --- debug: Database Library initialized
2008-12-17 15:53:27 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 15:53:27 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 15:53:27 +01:00 --- debug: Profiler Library initialized
2008-12-17 15:53:27 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 15:53:27 +01:00 --- debug: Database Library initialized
2008-12-17 15:54:25 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 15:54:25 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 15:54:25 +01:00 --- debug: Profiler Library initialized
2008-12-17 15:54:25 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 15:54:25 +01:00 --- debug: Database Library initialized
2008-12-17 15:55:10 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 15:55:10 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 15:55:10 +01:00 --- debug: Profiler Library initialized
2008-12-17 15:55:10 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 15:55:10 +01:00 --- debug: Database Library initialized
2008-12-17 15:55:30 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 15:55:30 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 15:55:30 +01:00 --- debug: Profiler Library initialized
2008-12-17 15:55:30 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 15:55:30 +01:00 --- debug: Database Library initialized
2008-12-17 15:55:48 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 15:55:48 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 15:55:48 +01:00 --- debug: Profiler Library initialized
2008-12-17 15:55:48 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 15:55:48 +01:00 --- debug: Database Library initialized
2008-12-17 15:56:31 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 15:56:31 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 15:56:31 +01:00 --- debug: Profiler Library initialized
2008-12-17 15:56:31 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 15:56:31 +01:00 --- debug: Database Library initialized
2008-12-17 16:02:03 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 16:02:03 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 16:02:03 +01:00 --- debug: Profiler Library initialized
2008-12-17 16:02:03 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 16:02:03 +01:00 --- debug: Database Library initialized
2008-12-17 16:02:23 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 16:02:23 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 16:02:23 +01:00 --- debug: Profiler Library initialized
2008-12-17 16:02:23 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 16:02:23 +01:00 --- debug: Database Library initialized
2008-12-17 16:02:56 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 16:02:56 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 16:02:56 +01:00 --- debug: Profiler Library initialized
2008-12-17 16:02:56 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 16:02:56 +01:00 --- debug: Database Library initialized
2008-12-17 16:04:21 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 16:04:21 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 16:04:21 +01:00 --- debug: Profiler Library initialized
2008-12-17 16:04:21 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 16:04:21 +01:00 --- debug: Database Library initialized
2008-12-17 16:04:31 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 16:04:31 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 16:04:31 +01:00 --- debug: Profiler Library initialized
2008-12-17 16:04:31 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 16:04:31 +01:00 --- debug: Database Library initialized
2008-12-17 16:04:49 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 16:04:49 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 16:04:49 +01:00 --- debug: Profiler Library initialized
2008-12-17 16:04:49 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 16:04:49 +01:00 --- debug: Database Library initialized
2008-12-17 16:05:10 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 16:05:10 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 16:05:10 +01:00 --- debug: Profiler Library initialized
2008-12-17 16:05:10 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 16:05:10 +01:00 --- debug: Database Library initialized
2008-12-17 16:05:17 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 16:05:17 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 16:05:17 +01:00 --- debug: Profiler Library initialized
2008-12-17 16:05:17 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 16:05:17 +01:00 --- debug: Database Library initialized
2008-12-17 16:05:34 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 16:05:34 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 16:05:34 +01:00 --- debug: Profiler Library initialized
2008-12-17 16:05:34 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 16:05:34 +01:00 --- debug: Database Library initialized
2008-12-17 16:05:53 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 16:05:53 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 16:05:53 +01:00 --- debug: Profiler Library initialized
2008-12-17 16:05:53 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 16:05:53 +01:00 --- debug: Database Library initialized
2008-12-17 16:06:09 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 16:06:09 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 16:06:09 +01:00 --- debug: Profiler Library initialized
2008-12-17 16:06:09 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 16:06:09 +01:00 --- debug: Database Library initialized
2008-12-17 16:06:28 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 16:06:28 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 16:06:28 +01:00 --- debug: Profiler Library initialized
2008-12-17 16:06:28 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 16:06:28 +01:00 --- debug: Database Library initialized
2008-12-17 16:08:08 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 16:08:08 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 16:08:08 +01:00 --- debug: Profiler Library initialized
2008-12-17 16:08:08 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 16:08:08 +01:00 --- debug: Database Library initialized
2008-12-17 16:09:07 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 16:09:07 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 16:09:07 +01:00 --- debug: Profiler Library initialized
2008-12-17 16:09:07 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 16:09:07 +01:00 --- debug: Database Library initialized
2008-12-17 16:09:29 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 16:09:29 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 16:09:29 +01:00 --- debug: Profiler Library initialized
2008-12-17 16:09:29 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 16:09:29 +01:00 --- debug: Database Library initialized
2008-12-17 16:10:06 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 16:10:06 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 16:10:06 +01:00 --- debug: Profiler Library initialized
2008-12-17 16:10:06 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 16:10:06 +01:00 --- debug: Database Library initialized
2008-12-17 16:10:22 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 16:10:22 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 16:10:22 +01:00 --- debug: Profiler Library initialized
2008-12-17 16:10:22 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 16:10:22 +01:00 --- debug: Database Library initialized
2008-12-17 16:10:36 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 16:10:36 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 16:10:36 +01:00 --- debug: Profiler Library initialized
2008-12-17 16:10:36 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 16:10:36 +01:00 --- debug: Database Library initialized
2008-12-17 16:11:35 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 16:11:35 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 16:11:35 +01:00 --- debug: Profiler Library initialized
2008-12-17 16:11:35 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 16:11:35 +01:00 --- debug: Database Library initialized
2008-12-17 16:12:40 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 16:12:40 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 16:12:40 +01:00 --- debug: Profiler Library initialized
2008-12-17 16:12:40 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 16:12:40 +01:00 --- debug: Database Library initialized
2008-12-17 16:13:10 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 16:13:10 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 16:13:10 +01:00 --- debug: Profiler Library initialized
2008-12-17 16:13:10 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 16:13:10 +01:00 --- debug: Database Library initialized
2008-12-17 16:13:42 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 16:13:42 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 16:13:42 +01:00 --- debug: Profiler Library initialized
2008-12-17 16:13:42 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 16:13:42 +01:00 --- debug: Database Library initialized
2008-12-17 16:13:53 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 16:13:53 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 16:13:53 +01:00 --- debug: Profiler Library initialized
2008-12-17 16:13:53 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 16:13:53 +01:00 --- debug: Database Library initialized
2008-12-17 16:14:15 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 16:14:15 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 16:14:15 +01:00 --- debug: Profiler Library initialized
2008-12-17 16:14:15 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 16:14:15 +01:00 --- debug: Database Library initialized
2008-12-17 16:14:49 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 16:14:49 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 16:14:49 +01:00 --- debug: Profiler Library initialized
2008-12-17 16:14:49 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 16:14:49 +01:00 --- debug: Database Library initialized
2008-12-17 16:15:35 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 16:15:35 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 16:15:35 +01:00 --- debug: Profiler Library initialized
2008-12-17 16:15:35 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 16:15:35 +01:00 --- debug: Database Library initialized
2008-12-17 16:15:47 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 16:15:47 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 16:15:47 +01:00 --- debug: Profiler Library initialized
2008-12-17 16:15:47 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 16:15:47 +01:00 --- debug: Database Library initialized
2008-12-17 16:16:03 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 16:16:03 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 16:16:03 +01:00 --- debug: Profiler Library initialized
2008-12-17 16:16:03 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 16:16:03 +01:00 --- debug: Database Library initialized
2008-12-17 16:16:54 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 16:16:54 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 16:16:54 +01:00 --- debug: Profiler Library initialized
2008-12-17 16:16:54 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 16:16:54 +01:00 --- debug: Database Library initialized
2008-12-17 16:17:35 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 16:17:35 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 16:17:35 +01:00 --- debug: Profiler Library initialized
2008-12-17 16:17:35 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 16:17:35 +01:00 --- debug: Database Library initialized
2008-12-17 16:17:55 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 16:17:55 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 16:17:55 +01:00 --- debug: Profiler Library initialized
2008-12-17 16:17:55 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 16:17:55 +01:00 --- debug: Database Library initialized
2008-12-17 16:18:05 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 16:18:05 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 16:18:05 +01:00 --- debug: Profiler Library initialized
2008-12-17 16:18:05 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 16:18:05 +01:00 --- debug: Database Library initialized
2008-12-17 16:18:17 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 16:18:17 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 16:18:17 +01:00 --- debug: Profiler Library initialized
2008-12-17 16:18:17 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 16:18:17 +01:00 --- debug: Database Library initialized
2008-12-17 16:18:32 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 16:18:32 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 16:18:32 +01:00 --- debug: Profiler Library initialized
2008-12-17 16:18:32 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 16:18:32 +01:00 --- debug: Database Library initialized
2008-12-17 16:18:51 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 16:18:51 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 16:18:51 +01:00 --- debug: Profiler Library initialized
2008-12-17 16:18:51 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 16:18:51 +01:00 --- debug: Database Library initialized
2008-12-17 16:19:02 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 16:19:02 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 16:19:02 +01:00 --- debug: Profiler Library initialized
2008-12-17 16:19:02 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 16:19:02 +01:00 --- debug: Database Library initialized
2008-12-17 16:22:48 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 16:22:48 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 16:22:48 +01:00 --- debug: Profiler Library initialized
2008-12-17 16:22:48 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 16:22:48 +01:00 --- debug: Database Library initialized
2008-12-17 16:24:25 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 16:24:25 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 16:24:25 +01:00 --- debug: Profiler Library initialized
2008-12-17 16:24:25 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 16:24:25 +01:00 --- debug: Database Library initialized
2008-12-17 16:26:32 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 16:26:32 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 16:26:32 +01:00 --- debug: Profiler Library initialized
2008-12-17 16:26:32 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 16:26:32 +01:00 --- debug: Database Library initialized
2008-12-17 16:27:07 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 16:27:07 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 16:27:07 +01:00 --- debug: Profiler Library initialized
2008-12-17 16:27:07 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 16:27:07 +01:00 --- debug: Database Library initialized
2008-12-17 16:27:30 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 16:27:30 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 16:27:30 +01:00 --- debug: Profiler Library initialized
2008-12-17 16:27:30 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 16:27:30 +01:00 --- debug: Database Library initialized
2008-12-17 16:28:15 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 16:28:15 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 16:28:15 +01:00 --- debug: Profiler Library initialized
2008-12-17 16:28:15 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 16:28:15 +01:00 --- debug: Database Library initialized
2008-12-17 16:28:22 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 16:28:22 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 16:28:22 +01:00 --- debug: Profiler Library initialized
2008-12-17 16:28:22 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 16:28:22 +01:00 --- debug: Database Library initialized
2008-12-17 16:34:40 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 16:34:40 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 16:34:40 +01:00 --- debug: Profiler Library initialized
2008-12-17 16:34:40 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 16:34:40 +01:00 --- debug: Database Library initialized
2008-12-17 16:35:08 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 16:35:08 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 16:35:08 +01:00 --- debug: Profiler Library initialized
2008-12-17 16:35:08 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 16:35:08 +01:00 --- debug: Database Library initialized
2008-12-17 16:35:24 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 16:35:24 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 16:35:24 +01:00 --- debug: Profiler Library initialized
2008-12-17 16:35:24 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 16:35:24 +01:00 --- debug: Database Library initialized
2008-12-17 16:35:39 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 16:35:39 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 16:35:39 +01:00 --- debug: Profiler Library initialized
2008-12-17 16:35:39 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 16:35:39 +01:00 --- debug: Database Library initialized
2008-12-17 16:36:39 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 16:36:39 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 16:36:39 +01:00 --- debug: Profiler Library initialized
2008-12-17 16:36:39 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 16:36:39 +01:00 --- debug: Database Library initialized
2008-12-17 16:36:42 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 16:36:42 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 16:36:42 +01:00 --- debug: Profiler Library initialized
2008-12-17 16:36:42 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 16:36:42 +01:00 --- debug: Database Library initialized
2008-12-17 16:36:54 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 16:36:54 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 16:36:54 +01:00 --- debug: Profiler Library initialized
2008-12-17 16:36:54 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 16:36:54 +01:00 --- debug: Database Library initialized
2008-12-17 16:37:58 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 16:37:58 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 16:37:58 +01:00 --- debug: Profiler Library initialized
2008-12-17 16:37:58 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 16:37:58 +01:00 --- debug: Database Library initialized
2008-12-17 16:44:07 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 16:44:07 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 16:44:07 +01:00 --- debug: Profiler Library initialized
2008-12-17 16:45:01 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 16:45:01 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 16:45:01 +01:00 --- debug: Profiler Library initialized
2008-12-17 16:45:01 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 16:45:01 +01:00 --- debug: Database Library initialized
2008-12-17 16:45:06 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 16:45:06 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 16:45:06 +01:00 --- debug: Profiler Library initialized
2008-12-17 16:45:06 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 16:45:06 +01:00 --- debug: Database Library initialized
2008-12-17 16:45:23 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 16:45:23 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 16:45:23 +01:00 --- debug: Profiler Library initialized
2008-12-17 16:45:23 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 16:45:23 +01:00 --- debug: Database Library initialized
2008-12-17 16:50:59 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 16:50:59 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 16:50:59 +01:00 --- debug: Profiler Library initialized
2008-12-17 16:50:59 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 16:50:59 +01:00 --- debug: Database Library initialized
2008-12-17 16:53:13 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 16:53:13 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 16:53:13 +01:00 --- debug: Profiler Library initialized
2008-12-17 16:53:13 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 16:53:13 +01:00 --- debug: Database Library initialized
2008-12-17 16:53:24 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 16:53:24 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 16:53:24 +01:00 --- debug: Profiler Library initialized
2008-12-17 16:53:24 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 16:53:24 +01:00 --- debug: Database Library initialized
2008-12-17 16:55:20 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 16:55:20 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 16:55:20 +01:00 --- debug: Profiler Library initialized
2008-12-17 16:55:20 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 16:55:20 +01:00 --- debug: Database Library initialized
2008-12-17 16:55:32 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 16:55:32 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 16:55:32 +01:00 --- debug: Profiler Library initialized
2008-12-17 16:55:32 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 16:55:32 +01:00 --- debug: Database Library initialized
2008-12-17 16:58:37 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 16:58:37 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 16:58:37 +01:00 --- debug: Profiler Library initialized
2008-12-17 16:58:37 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 16:58:37 +01:00 --- debug: Database Library initialized
2008-12-17 18:12:12 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 18:12:12 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 18:12:12 +01:00 --- debug: Profiler Library initialized
2008-12-17 18:12:12 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 18:12:12 +01:00 --- debug: Database Library initialized
2008-12-17 18:12:33 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 18:12:33 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 18:12:33 +01:00 --- debug: Profiler Library initialized
2008-12-17 18:12:33 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 18:12:33 +01:00 --- debug: Database Library initialized
2008-12-17 18:12:42 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 18:12:42 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 18:12:42 +01:00 --- debug: Profiler Library initialized
2008-12-17 18:12:42 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 18:12:42 +01:00 --- debug: Database Library initialized
2008-12-17 18:19:53 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 18:19:53 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 18:19:53 +01:00 --- debug: Profiler Library initialized
2008-12-17 18:19:53 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 18:19:53 +01:00 --- debug: Database Library initialized
2008-12-17 18:26:47 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 18:26:47 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 18:26:47 +01:00 --- debug: Profiler Library initialized
2008-12-17 18:26:47 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 18:26:47 +01:00 --- debug: Database Library initialized
2008-12-17 18:27:10 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 18:27:10 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 18:27:10 +01:00 --- debug: Profiler Library initialized
2008-12-17 18:27:10 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 18:27:10 +01:00 --- debug: Database Library initialized
2008-12-17 18:27:29 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 18:27:29 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 18:27:29 +01:00 --- debug: Profiler Library initialized
2008-12-17 18:27:29 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 18:27:29 +01:00 --- debug: Database Library initialized
2008-12-17 18:27:30 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 18:27:30 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 18:27:30 +01:00 --- debug: Profiler Library initialized
2008-12-17 18:27:30 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 18:27:30 +01:00 --- debug: Database Library initialized
2008-12-17 18:28:03 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 18:28:03 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 18:28:03 +01:00 --- debug: Profiler Library initialized
2008-12-17 18:28:03 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 18:28:03 +01:00 --- debug: Database Library initialized
2008-12-17 18:28:03 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 18:28:03 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 18:28:03 +01:00 --- debug: Profiler Library initialized
2008-12-17 18:28:03 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 18:28:03 +01:00 --- debug: Database Library initialized
2008-12-17 18:28:04 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 18:28:04 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 18:28:04 +01:00 --- debug: Profiler Library initialized
2008-12-17 18:28:04 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 18:28:04 +01:00 --- debug: Database Library initialized
2008-12-17 18:28:04 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 18:28:04 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 18:28:04 +01:00 --- debug: Profiler Library initialized
2008-12-17 18:28:04 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 18:28:04 +01:00 --- debug: Database Library initialized
2008-12-17 18:28:04 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 18:28:04 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 18:28:04 +01:00 --- debug: Profiler Library initialized
2008-12-17 18:28:04 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 18:28:04 +01:00 --- debug: Database Library initialized
2008-12-17 18:28:39 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 18:28:39 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 18:28:39 +01:00 --- debug: Profiler Library initialized
2008-12-17 18:28:39 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 18:28:39 +01:00 --- debug: Database Library initialized
2008-12-17 18:29:05 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 18:29:05 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 18:29:05 +01:00 --- debug: Profiler Library initialized
2008-12-17 18:29:05 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 18:29:05 +01:00 --- debug: Database Library initialized
2008-12-17 18:29:55 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 18:29:55 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 18:29:55 +01:00 --- debug: Profiler Library initialized
2008-12-17 18:29:55 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 18:29:55 +01:00 --- debug: Database Library initialized
2008-12-17 18:30:34 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 18:30:34 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 18:30:34 +01:00 --- debug: Profiler Library initialized
2008-12-17 18:30:34 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 18:30:34 +01:00 --- debug: Database Library initialized
2008-12-17 18:31:13 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 18:31:13 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 18:31:13 +01:00 --- debug: Profiler Library initialized
2008-12-17 18:31:13 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 18:31:13 +01:00 --- debug: Database Library initialized
2008-12-17 18:32:49 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 18:32:49 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 18:32:49 +01:00 --- debug: Profiler Library initialized
2008-12-17 18:32:49 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 18:32:49 +01:00 --- debug: Database Library initialized
2008-12-17 18:32:49 +01:00 --- error: Missing i18n entry resource.id for language cs_CZ
2008-12-17 18:32:49 +01:00 --- error: Missing i18n entry resource.curator_id for language cs_CZ
2008-12-17 18:32:49 +01:00 --- error: Missing i18n entry resource.contact_id for language cs_CZ
2008-12-17 18:32:49 +01:00 --- error: Missing i18n entry resource.publisher_id for language cs_CZ
2008-12-17 18:32:49 +01:00 --- error: Missing i18n entry resource.contract_id for language cs_CZ
2008-12-17 18:32:49 +01:00 --- error: Missing i18n entry resource.conspectus_id for language cs_CZ
2008-12-17 18:32:49 +01:00 --- error: Missing i18n entry resource.crawl_freq_id for language cs_CZ
2008-12-17 18:32:49 +01:00 --- error: Missing i18n entry resource.resource_status_id for language cs_CZ
2008-12-17 18:32:49 +01:00 --- error: Missing i18n entry resource.suggested_by_id for language cs_CZ
2008-12-17 18:32:49 +01:00 --- error: Missing i18n entry resource.title for language cs_CZ
2008-12-17 18:32:49 +01:00 --- error: Missing i18n entry resource.url for language cs_CZ
2008-12-17 18:32:49 +01:00 --- error: Missing i18n entry resource.rating_result for language cs_CZ
2008-12-17 18:32:49 +01:00 --- error: Missing i18n entry resource.date for language cs_CZ
2008-12-17 18:32:49 +01:00 --- error: Missing i18n entry resource.aleph_id for language cs_CZ
2008-12-17 18:32:49 +01:00 --- error: Missing i18n entry resource.ISSN for language cs_CZ
2008-12-17 18:32:49 +01:00 --- error: Missing i18n entry resource.metadata for language cs_CZ
2008-12-17 18:32:49 +01:00 --- error: Missing i18n entry resource.catalogued for language cs_CZ
2008-12-17 18:32:49 +01:00 --- error: Missing i18n entry resource.creative_commons for language cs_CZ
2008-12-17 18:32:49 +01:00 --- error: Missing i18n entry resource.tech_problems for language cs_CZ
2008-12-17 18:32:49 +01:00 --- error: Missing i18n entry resource.comments for language cs_CZ
2008-12-17 18:34:21 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 18:34:21 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 18:34:21 +01:00 --- debug: Profiler Library initialized
2008-12-17 18:34:21 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 18:34:21 +01:00 --- debug: Database Library initialized
2008-12-17 18:34:44 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-17 18:34:44 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-17 18:34:44 +01:00 --- debug: Profiler Library initialized
2008-12-17 18:34:44 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-17 18:34:44 +01:00 --- debug: Database Library initialized
2008-12-17 18:34:44 +01:00 --- error: Missing i18n entry resource.id for language cs_CZ
2008-12-17 18:34:44 +01:00 --- error: Missing i18n entry resource.curator_id for language cs_CZ
2008-12-17 18:34:44 +01:00 --- error: Missing i18n entry resource.contact_id for language cs_CZ
2008-12-17 18:34:44 +01:00 --- error: Missing i18n entry resource.publisher_id for language cs_CZ
2008-12-17 18:34:44 +01:00 --- error: Missing i18n entry resource.contract_id for language cs_CZ
2008-12-17 18:34:44 +01:00 --- error: Missing i18n entry resource.conspectus_id for language cs_CZ
2008-12-17 18:34:44 +01:00 --- error: Missing i18n entry resource.crawl_freq_id for language cs_CZ
2008-12-17 18:34:44 +01:00 --- error: Missing i18n entry resource.resource_status_id for language cs_CZ
2008-12-17 18:34:44 +01:00 --- error: Missing i18n entry resource.suggested_by_id for language cs_CZ
2008-12-17 18:34:44 +01:00 --- error: Missing i18n entry resource.title for language cs_CZ
2008-12-17 18:34:44 +01:00 --- error: Missing i18n entry resource.url for language cs_CZ
2008-12-17 18:34:44 +01:00 --- error: Missing i18n entry resource.rating_result for language cs_CZ
2008-12-17 18:34:44 +01:00 --- error: Missing i18n entry resource.date for language cs_CZ
2008-12-17 18:34:44 +01:00 --- error: Missing i18n entry resource.aleph_id for language cs_CZ
2008-12-17 18:34:44 +01:00 --- error: Missing i18n entry resource.ISSN for language cs_CZ
2008-12-17 18:34:44 +01:00 --- error: Missing i18n entry resource.metadata for language cs_CZ
2008-12-17 18:34:44 +01:00 --- error: Missing i18n entry resource.catalogued for language cs_CZ
2008-12-17 18:34:44 +01:00 --- error: Missing i18n entry resource.creative_commons for language cs_CZ
2008-12-17 18:34:44 +01:00 --- error: Missing i18n entry resource.tech_problems for language cs_CZ
2008-12-17 18:34:44 +01:00 --- error: Missing i18n entry resource.comments for language cs_CZ
