<?php defined('SYSPATH') or die('No direct script access.'); ?>

2009-01-04 12:19:47 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2009-01-04 12:19:47 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2009-01-04 12:19:47 +01:00 --- debug: Profiler Library initialized
2009-01-04 12:19:47 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2009-01-04 12:19:47 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2009-01-04 12:19:47 +01:00 --- debug: Profiler Library initialized
2009-01-04 12:19:48 +01:00 --- debug: MySQL Database Driver Initialized
2009-01-04 12:19:48 +01:00 --- debug: Database Library initialized
2009-01-04 12:19:49 +01:00 --- debug: Pagination Library initialized
2009-01-04 12:19:49 +01:00 --- debug: Pagination Library initialized
2009-01-04 12:19:47 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2009-01-04 12:19:47 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2009-01-04 12:19:47 +01:00 --- debug: Profiler Library initialized
2009-01-04 12:19:48 +01:00 --- debug: MySQL Database Driver Initialized
2009-01-04 12:19:48 +01:00 --- debug: Database Library initialized
