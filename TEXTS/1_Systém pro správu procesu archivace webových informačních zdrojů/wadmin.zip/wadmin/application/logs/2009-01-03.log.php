<?php defined('SYSPATH') or die('No direct script access.'); ?>

2009-01-03 00:00:00 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2009-01-03 00:00:00 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2009-01-03 00:00:00 +01:00 --- debug: Profiler Library initialized
2009-01-03 00:00:00 +01:00 --- debug: MySQL Database Driver Initialized
2009-01-03 00:00:00 +01:00 --- debug: Database Library initialized
2009-01-03 00:00:00 +01:00 --- debug: Pagination Library initialized
2009-01-03 00:00:29 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2009-01-03 00:00:29 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2009-01-03 00:00:29 +01:00 --- debug: Profiler Library initialized
2009-01-03 00:00:29 +01:00 --- debug: MySQL Database Driver Initialized
2009-01-03 00:00:29 +01:00 --- debug: Database Library initialized
2009-01-03 00:00:29 +01:00 --- debug: Pagination Library initialized
2009-01-03 00:01:52 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2009-01-03 00:01:52 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2009-01-03 00:01:52 +01:00 --- debug: Profiler Library initialized
2009-01-03 00:01:52 +01:00 --- debug: MySQL Database Driver Initialized
2009-01-03 00:01:52 +01:00 --- debug: Database Library initialized
2009-01-03 00:01:52 +01:00 --- debug: Pagination Library initialized
2009-01-03 00:02:24 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2009-01-03 00:02:24 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2009-01-03 00:02:24 +01:00 --- debug: Profiler Library initialized
2009-01-03 00:02:24 +01:00 --- debug: MySQL Database Driver Initialized
2009-01-03 00:02:24 +01:00 --- debug: Database Library initialized
2009-01-03 00:02:24 +01:00 --- debug: Pagination Library initialized
2009-01-03 00:02:26 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2009-01-03 00:02:26 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2009-01-03 00:02:26 +01:00 --- debug: Profiler Library initialized
2009-01-03 00:02:26 +01:00 --- debug: MySQL Database Driver Initialized
2009-01-03 00:02:26 +01:00 --- debug: Database Library initialized
2009-01-03 00:02:26 +01:00 --- debug: Pagination Library initialized
2009-01-03 00:02:28 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2009-01-03 00:02:28 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2009-01-03 00:02:28 +01:00 --- debug: Profiler Library initialized
2009-01-03 00:02:28 +01:00 --- debug: MySQL Database Driver Initialized
2009-01-03 00:02:28 +01:00 --- debug: Database Library initialized
2009-01-03 00:02:28 +01:00 --- debug: Pagination Library initialized
2009-01-03 00:02:30 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2009-01-03 00:02:30 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2009-01-03 00:02:30 +01:00 --- debug: Profiler Library initialized
2009-01-03 00:02:30 +01:00 --- debug: MySQL Database Driver Initialized
2009-01-03 00:02:30 +01:00 --- debug: Database Library initialized
2009-01-03 00:02:30 +01:00 --- debug: Pagination Library initialized
2009-01-03 00:02:36 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2009-01-03 00:02:36 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2009-01-03 00:02:36 +01:00 --- debug: Profiler Library initialized
2009-01-03 00:02:36 +01:00 --- debug: MySQL Database Driver Initialized
2009-01-03 00:02:36 +01:00 --- debug: Database Library initialized
2009-01-03 00:02:36 +01:00 --- debug: Pagination Library initialized
2009-01-03 00:02:38 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2009-01-03 00:02:38 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2009-01-03 00:02:38 +01:00 --- debug: Profiler Library initialized
2009-01-03 00:02:38 +01:00 --- debug: MySQL Database Driver Initialized
2009-01-03 00:02:38 +01:00 --- debug: Database Library initialized
2009-01-03 00:02:38 +01:00 --- debug: Pagination Library initialized
2009-01-03 00:06:16 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2009-01-03 00:06:16 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2009-01-03 00:06:16 +01:00 --- debug: Profiler Library initialized
2009-01-03 00:06:16 +01:00 --- debug: MySQL Database Driver Initialized
2009-01-03 00:06:16 +01:00 --- debug: Database Library initialized
2009-01-03 00:06:16 +01:00 --- debug: Pagination Library initialized
2009-01-03 00:09:58 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2009-01-03 00:09:58 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2009-01-03 00:09:58 +01:00 --- debug: Profiler Library initialized
2009-01-03 00:09:58 +01:00 --- debug: MySQL Database Driver Initialized
2009-01-03 00:09:58 +01:00 --- debug: Database Library initialized
2009-01-03 00:09:58 +01:00 --- debug: Pagination Library initialized
2009-01-03 00:14:34 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2009-01-03 00:14:34 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2009-01-03 00:14:34 +01:00 --- debug: Profiler Library initialized
2009-01-03 00:14:34 +01:00 --- debug: MySQL Database Driver Initialized
2009-01-03 00:14:34 +01:00 --- debug: Database Library initialized
2009-01-03 00:14:34 +01:00 --- debug: Pagination Library initialized
2009-01-03 00:24:03 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2009-01-03 00:24:03 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2009-01-03 00:24:03 +01:00 --- debug: Profiler Library initialized
2009-01-03 00:24:03 +01:00 --- debug: MySQL Database Driver Initialized
2009-01-03 00:24:03 +01:00 --- debug: Database Library initialized
2009-01-03 00:24:03 +01:00 --- debug: Pagination Library initialized
2009-01-03 00:25:14 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2009-01-03 00:25:14 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2009-01-03 00:25:14 +01:00 --- debug: Profiler Library initialized
2009-01-03 00:25:14 +01:00 --- debug: MySQL Database Driver Initialized
2009-01-03 00:25:14 +01:00 --- debug: Database Library initialized
2009-01-03 00:25:14 +01:00 --- debug: Pagination Library initialized
2009-01-03 00:30:18 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2009-01-03 00:30:18 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2009-01-03 00:30:18 +01:00 --- debug: Profiler Library initialized
2009-01-03 00:30:18 +01:00 --- debug: MySQL Database Driver Initialized
2009-01-03 00:30:18 +01:00 --- debug: Database Library initialized
2009-01-03 00:30:18 +01:00 --- debug: Pagination Library initialized
2009-01-03 00:30:54 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2009-01-03 00:30:54 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2009-01-03 00:30:54 +01:00 --- debug: Profiler Library initialized
2009-01-03 00:30:54 +01:00 --- debug: MySQL Database Driver Initialized
2009-01-03 00:30:54 +01:00 --- debug: Database Library initialized
2009-01-03 00:30:54 +01:00 --- debug: Pagination Library initialized
2009-01-03 00:31:58 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2009-01-03 00:31:58 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2009-01-03 00:31:58 +01:00 --- debug: Profiler Library initialized
2009-01-03 00:31:58 +01:00 --- debug: MySQL Database Driver Initialized
2009-01-03 00:31:58 +01:00 --- debug: Database Library initialized
2009-01-03 00:31:58 +01:00 --- debug: Pagination Library initialized
2009-01-03 00:34:05 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2009-01-03 00:34:05 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2009-01-03 00:34:05 +01:00 --- debug: Profiler Library initialized
2009-01-03 00:34:05 +01:00 --- debug: MySQL Database Driver Initialized
2009-01-03 00:34:05 +01:00 --- debug: Database Library initialized
2009-01-03 00:34:05 +01:00 --- debug: Pagination Library initialized
2009-01-03 00:45:00 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2009-01-03 00:45:00 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2009-01-03 00:45:00 +01:00 --- debug: Profiler Library initialized
2009-01-03 00:45:00 +01:00 --- debug: MySQL Database Driver Initialized
2009-01-03 00:45:00 +01:00 --- debug: Database Library initialized
2009-01-03 00:45:00 +01:00 --- debug: Pagination Library initialized
2009-01-03 00:47:11 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2009-01-03 00:47:11 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2009-01-03 00:47:11 +01:00 --- debug: Profiler Library initialized
2009-01-03 00:47:11 +01:00 --- debug: MySQL Database Driver Initialized
2009-01-03 00:47:11 +01:00 --- debug: Database Library initialized
2009-01-03 00:47:11 +01:00 --- debug: Pagination Library initialized
2009-01-03 00:47:13 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2009-01-03 00:47:13 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2009-01-03 00:47:13 +01:00 --- debug: Profiler Library initialized
2009-01-03 00:47:13 +01:00 --- debug: MySQL Database Driver Initialized
2009-01-03 00:47:13 +01:00 --- debug: Database Library initialized
2009-01-03 00:47:13 +01:00 --- debug: Pagination Library initialized
2009-01-03 00:47:36 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2009-01-03 00:47:36 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2009-01-03 00:47:36 +01:00 --- debug: Profiler Library initialized
2009-01-03 00:47:36 +01:00 --- debug: MySQL Database Driver Initialized
2009-01-03 00:47:36 +01:00 --- debug: Database Library initialized
2009-01-03 00:47:36 +01:00 --- debug: Pagination Library initialized
2009-01-03 00:49:42 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2009-01-03 00:49:42 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2009-01-03 00:49:42 +01:00 --- debug: Profiler Library initialized
2009-01-03 00:49:42 +01:00 --- debug: MySQL Database Driver Initialized
2009-01-03 00:49:42 +01:00 --- debug: Database Library initialized
2009-01-03 00:49:42 +01:00 --- debug: Pagination Library initialized
2009-01-03 00:52:10 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2009-01-03 00:52:10 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2009-01-03 00:52:10 +01:00 --- debug: Profiler Library initialized
2009-01-03 00:52:10 +01:00 --- debug: MySQL Database Driver Initialized
2009-01-03 00:52:10 +01:00 --- debug: Database Library initialized
2009-01-03 00:52:10 +01:00 --- debug: Pagination Library initialized
2009-01-03 00:53:40 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2009-01-03 00:53:40 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2009-01-03 00:53:40 +01:00 --- debug: Profiler Library initialized
2009-01-03 00:53:40 +01:00 --- debug: MySQL Database Driver Initialized
2009-01-03 00:53:40 +01:00 --- debug: Database Library initialized
2009-01-03 00:53:40 +01:00 --- debug: Pagination Library initialized
2009-01-03 00:53:43 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2009-01-03 00:53:43 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2009-01-03 00:53:43 +01:00 --- debug: Profiler Library initialized
2009-01-03 00:53:43 +01:00 --- debug: MySQL Database Driver Initialized
2009-01-03 00:53:43 +01:00 --- debug: Database Library initialized
2009-01-03 00:53:43 +01:00 --- debug: Pagination Library initialized
2009-01-03 00:53:47 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2009-01-03 00:53:47 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2009-01-03 00:53:47 +01:00 --- debug: Profiler Library initialized
2009-01-03 00:53:47 +01:00 --- debug: MySQL Database Driver Initialized
2009-01-03 00:53:47 +01:00 --- debug: Database Library initialized
2009-01-03 00:53:47 +01:00 --- debug: Pagination Library initialized
2009-01-03 00:54:01 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2009-01-03 00:54:01 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2009-01-03 00:54:01 +01:00 --- debug: Profiler Library initialized
2009-01-03 00:54:01 +01:00 --- debug: MySQL Database Driver Initialized
2009-01-03 00:54:01 +01:00 --- debug: Database Library initialized
2009-01-03 00:54:01 +01:00 --- debug: Pagination Library initialized
2009-01-03 00:54:07 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2009-01-03 00:54:07 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2009-01-03 00:54:07 +01:00 --- debug: Profiler Library initialized
2009-01-03 00:54:07 +01:00 --- debug: MySQL Database Driver Initialized
2009-01-03 00:54:07 +01:00 --- debug: Database Library initialized
2009-01-03 00:54:07 +01:00 --- debug: Pagination Library initialized
2009-01-03 00:54:13 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2009-01-03 00:54:13 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2009-01-03 00:54:13 +01:00 --- debug: Profiler Library initialized
2009-01-03 00:54:13 +01:00 --- debug: MySQL Database Driver Initialized
2009-01-03 00:54:13 +01:00 --- debug: Database Library initialized
2009-01-03 00:54:13 +01:00 --- debug: Pagination Library initialized
2009-01-03 00:54:30 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2009-01-03 00:54:30 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2009-01-03 00:54:30 +01:00 --- debug: Profiler Library initialized
2009-01-03 00:54:30 +01:00 --- debug: MySQL Database Driver Initialized
2009-01-03 00:54:30 +01:00 --- debug: Database Library initialized
2009-01-03 00:54:30 +01:00 --- debug: Pagination Library initialized
2009-01-03 00:55:00 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2009-01-03 00:55:00 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2009-01-03 00:55:00 +01:00 --- debug: Profiler Library initialized
2009-01-03 00:55:00 +01:00 --- debug: MySQL Database Driver Initialized
2009-01-03 00:55:00 +01:00 --- debug: Database Library initialized
2009-01-03 00:55:00 +01:00 --- debug: Pagination Library initialized
2009-01-03 00:56:44 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2009-01-03 00:56:44 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2009-01-03 00:56:44 +01:00 --- debug: Profiler Library initialized
2009-01-03 00:56:44 +01:00 --- debug: MySQL Database Driver Initialized
2009-01-03 00:56:44 +01:00 --- debug: Database Library initialized
2009-01-03 00:56:44 +01:00 --- debug: Pagination Library initialized
2009-01-03 00:56:47 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2009-01-03 00:56:47 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2009-01-03 00:56:47 +01:00 --- debug: Profiler Library initialized
2009-01-03 00:56:47 +01:00 --- debug: MySQL Database Driver Initialized
2009-01-03 00:56:47 +01:00 --- debug: Database Library initialized
2009-01-03 00:56:47 +01:00 --- debug: Pagination Library initialized
2009-01-03 00:56:52 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2009-01-03 00:56:52 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2009-01-03 00:56:52 +01:00 --- debug: Profiler Library initialized
2009-01-03 00:56:52 +01:00 --- debug: MySQL Database Driver Initialized
2009-01-03 00:56:52 +01:00 --- debug: Database Library initialized
2009-01-03 00:56:52 +01:00 --- debug: Pagination Library initialized
2009-01-03 00:56:55 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2009-01-03 00:56:55 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2009-01-03 00:56:55 +01:00 --- debug: Profiler Library initialized
2009-01-03 00:56:55 +01:00 --- debug: MySQL Database Driver Initialized
2009-01-03 00:56:55 +01:00 --- debug: Database Library initialized
2009-01-03 00:56:55 +01:00 --- debug: Pagination Library initialized
2009-01-03 01:00:25 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2009-01-03 01:00:25 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2009-01-03 01:00:25 +01:00 --- debug: Profiler Library initialized
2009-01-03 01:00:25 +01:00 --- debug: MySQL Database Driver Initialized
2009-01-03 01:00:25 +01:00 --- debug: Database Library initialized
2009-01-03 01:00:25 +01:00 --- debug: Pagination Library initialized
2009-01-03 01:00:28 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2009-01-03 01:00:28 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2009-01-03 01:00:28 +01:00 --- debug: Profiler Library initialized
2009-01-03 01:00:28 +01:00 --- debug: MySQL Database Driver Initialized
2009-01-03 01:00:28 +01:00 --- debug: Database Library initialized
2009-01-03 01:00:28 +01:00 --- debug: Pagination Library initialized
2009-01-03 01:00:31 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2009-01-03 01:00:31 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2009-01-03 01:00:31 +01:00 --- debug: Profiler Library initialized
2009-01-03 01:00:31 +01:00 --- debug: MySQL Database Driver Initialized
2009-01-03 01:00:31 +01:00 --- debug: Database Library initialized
2009-01-03 01:00:31 +01:00 --- debug: Pagination Library initialized
2009-01-03 01:00:33 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2009-01-03 01:00:33 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2009-01-03 01:00:33 +01:00 --- debug: Profiler Library initialized
2009-01-03 01:00:33 +01:00 --- debug: MySQL Database Driver Initialized
2009-01-03 01:00:33 +01:00 --- debug: Database Library initialized
2009-01-03 01:00:33 +01:00 --- debug: Pagination Library initialized
2009-01-03 01:00:36 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2009-01-03 01:00:36 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2009-01-03 01:00:36 +01:00 --- debug: Profiler Library initialized
2009-01-03 01:00:36 +01:00 --- debug: MySQL Database Driver Initialized
2009-01-03 01:00:36 +01:00 --- debug: Database Library initialized
2009-01-03 01:00:36 +01:00 --- debug: Pagination Library initialized
2009-01-03 01:00:39 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2009-01-03 01:00:39 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2009-01-03 01:00:39 +01:00 --- debug: Profiler Library initialized
2009-01-03 01:00:39 +01:00 --- debug: MySQL Database Driver Initialized
2009-01-03 01:00:39 +01:00 --- debug: Database Library initialized
2009-01-03 01:00:39 +01:00 --- debug: Pagination Library initialized
2009-01-03 01:00:42 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2009-01-03 01:00:42 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2009-01-03 01:00:42 +01:00 --- debug: Profiler Library initialized
2009-01-03 01:00:42 +01:00 --- debug: MySQL Database Driver Initialized
2009-01-03 01:00:42 +01:00 --- debug: Database Library initialized
2009-01-03 01:00:42 +01:00 --- debug: Pagination Library initialized
2009-01-03 01:02:38 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2009-01-03 01:02:38 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2009-01-03 01:02:38 +01:00 --- debug: Profiler Library initialized
2009-01-03 01:02:38 +01:00 --- debug: MySQL Database Driver Initialized
2009-01-03 01:02:38 +01:00 --- debug: Database Library initialized
2009-01-03 01:02:38 +01:00 --- debug: Pagination Library initialized
2009-01-03 01:02:38 +01:00 --- debug: Pagination Library initialized
2009-01-03 01:02:56 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2009-01-03 01:02:56 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2009-01-03 01:02:56 +01:00 --- debug: Profiler Library initialized
2009-01-03 01:02:56 +01:00 --- debug: MySQL Database Driver Initialized
2009-01-03 01:02:56 +01:00 --- debug: Database Library initialized
2009-01-03 01:02:56 +01:00 --- debug: Pagination Library initialized
2009-01-03 01:02:56 +01:00 --- debug: Pagination Library initialized
2009-01-03 01:03:43 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2009-01-03 01:03:43 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2009-01-03 01:03:43 +01:00 --- debug: Profiler Library initialized
2009-01-03 01:03:43 +01:00 --- debug: MySQL Database Driver Initialized
2009-01-03 01:03:43 +01:00 --- debug: Database Library initialized
2009-01-03 01:03:43 +01:00 --- debug: Pagination Library initialized
2009-01-03 01:03:43 +01:00 --- debug: Pagination Library initialized
2009-01-03 01:08:01 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2009-01-03 01:08:01 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2009-01-03 01:08:01 +01:00 --- debug: Profiler Library initialized
2009-01-03 01:08:01 +01:00 --- debug: MySQL Database Driver Initialized
2009-01-03 01:08:01 +01:00 --- debug: Database Library initialized
2009-01-03 01:08:01 +01:00 --- debug: Pagination Library initialized
2009-01-03 01:08:01 +01:00 --- debug: Pagination Library initialized
2009-01-03 01:09:07 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2009-01-03 01:09:07 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2009-01-03 01:09:07 +01:00 --- debug: Profiler Library initialized
2009-01-03 01:09:07 +01:00 --- debug: MySQL Database Driver Initialized
2009-01-03 01:09:07 +01:00 --- debug: Database Library initialized
2009-01-03 01:09:07 +01:00 --- debug: Pagination Library initialized
2009-01-03 01:09:07 +01:00 --- debug: Pagination Library initialized
2009-01-03 01:09:07 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2009-01-03 01:09:07 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2009-01-03 01:09:07 +01:00 --- debug: Profiler Library initialized
2009-01-03 01:09:07 +01:00 --- debug: MySQL Database Driver Initialized
2009-01-03 01:09:07 +01:00 --- debug: Database Library initialized
2009-01-03 01:09:07 +01:00 --- debug: Pagination Library initialized
2009-01-03 01:09:07 +01:00 --- debug: Pagination Library initialized
2009-01-03 01:10:26 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2009-01-03 01:10:26 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2009-01-03 01:10:26 +01:00 --- debug: Profiler Library initialized
2009-01-03 01:10:26 +01:00 --- debug: MySQL Database Driver Initialized
2009-01-03 01:10:26 +01:00 --- debug: Database Library initialized
2009-01-03 01:10:26 +01:00 --- debug: Pagination Library initialized
2009-01-03 01:10:26 +01:00 --- debug: Pagination Library initialized
2009-01-03 01:10:40 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2009-01-03 01:10:40 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2009-01-03 01:10:40 +01:00 --- debug: Profiler Library initialized
2009-01-03 01:13:00 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2009-01-03 01:13:00 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2009-01-03 01:13:00 +01:00 --- debug: Profiler Library initialized
2009-01-03 01:13:01 +01:00 --- debug: MySQL Database Driver Initialized
2009-01-03 01:13:01 +01:00 --- debug: Database Library initialized
2009-01-03 01:13:01 +01:00 --- debug: Pagination Library initialized
2009-01-03 01:13:01 +01:00 --- debug: Pagination Library initialized
2009-01-03 01:13:22 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2009-01-03 01:13:22 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2009-01-03 01:13:22 +01:00 --- debug: Profiler Library initialized
2009-01-03 01:13:22 +01:00 --- debug: MySQL Database Driver Initialized
2009-01-03 01:13:22 +01:00 --- debug: Database Library initialized
2009-01-03 01:13:22 +01:00 --- debug: Pagination Library initialized
2009-01-03 01:13:22 +01:00 --- debug: Pagination Library initialized
2009-01-03 01:13:23 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2009-01-03 01:13:23 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2009-01-03 01:13:23 +01:00 --- debug: Profiler Library initialized
2009-01-03 01:22:56 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2009-01-03 01:22:56 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2009-01-03 01:22:56 +01:00 --- debug: Profiler Library initialized
2009-01-03 01:22:56 +01:00 --- debug: MySQL Database Driver Initialized
2009-01-03 01:22:56 +01:00 --- debug: Database Library initialized
2009-01-03 01:22:56 +01:00 --- debug: Pagination Library initialized
2009-01-03 01:22:56 +01:00 --- debug: Pagination Library initialized
2009-01-03 01:22:59 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2009-01-03 01:22:59 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2009-01-03 01:22:59 +01:00 --- debug: Profiler Library initialized
2009-01-03 01:22:59 +01:00 --- debug: MySQL Database Driver Initialized
2009-01-03 01:22:59 +01:00 --- debug: Database Library initialized
2009-01-03 01:22:59 +01:00 --- debug: Pagination Library initialized
2009-01-03 01:22:59 +01:00 --- debug: Pagination Library initialized
2009-01-03 01:23:01 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2009-01-03 01:23:01 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2009-01-03 01:23:01 +01:00 --- debug: Profiler Library initialized
2009-01-03 01:23:01 +01:00 --- debug: MySQL Database Driver Initialized
2009-01-03 01:23:01 +01:00 --- debug: Database Library initialized
2009-01-03 01:23:01 +01:00 --- debug: Pagination Library initialized
2009-01-03 01:23:01 +01:00 --- debug: Pagination Library initialized
2009-01-03 12:57:18 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2009-01-03 12:57:18 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2009-01-03 12:57:18 +01:00 --- debug: Profiler Library initialized
2009-01-03 12:57:18 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2009-01-03 12:57:18 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2009-01-03 12:57:18 +01:00 --- debug: Profiler Library initialized
2009-01-03 12:57:19 +01:00 --- debug: MySQL Database Driver Initialized
2009-01-03 12:57:19 +01:00 --- debug: Database Library initialized
2009-01-03 12:57:18 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2009-01-03 12:57:18 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2009-01-03 12:57:18 +01:00 --- debug: Profiler Library initialized
2009-01-03 12:57:19 +01:00 --- debug: MySQL Database Driver Initialized
2009-01-03 12:57:19 +01:00 --- debug: Database Library initialized
2009-01-03 12:57:19 +01:00 --- debug: Pagination Library initialized
2009-01-03 12:57:19 +01:00 --- debug: Pagination Library initialized
2009-01-03 15:09:11 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2009-01-03 15:09:11 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2009-01-03 15:09:11 +01:00 --- debug: Profiler Library initialized
2009-01-03 15:09:11 +01:00 --- debug: MySQL Database Driver Initialized
2009-01-03 15:09:11 +01:00 --- debug: Database Library initialized
2009-01-03 15:09:11 +01:00 --- debug: Pagination Library initialized
2009-01-03 15:09:11 +01:00 --- debug: Pagination Library initialized
