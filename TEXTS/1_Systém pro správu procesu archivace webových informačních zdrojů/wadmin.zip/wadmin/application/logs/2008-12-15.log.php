<?php defined('SYSPATH') or die('No direct script access.'); ?>

2008-12-15 14:53:35 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-15 14:53:35 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-15 14:53:35 +01:00 --- debug: Profiler Library initialized
2008-12-15 14:53:35 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-15 14:53:35 +01:00 --- debug: Database Library initialized
2008-12-15 15:01:49 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-15 15:01:49 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-15 15:01:49 +01:00 --- debug: Profiler Library initialized
2008-12-15 15:01:49 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-15 15:01:49 +01:00 --- debug: Database Library initialized
2008-12-15 15:01:49 +01:00 --- error: Missing i18n entry tables.position for language cs_CZ
2008-12-15 15:01:56 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-15 15:01:56 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-15 15:01:56 +01:00 --- debug: Profiler Library initialized
2008-12-15 15:01:57 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-15 15:01:57 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-15 15:01:57 +01:00 --- debug: Profiler Library initialized
2008-12-15 15:02:04 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-15 15:02:04 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-15 15:02:04 +01:00 --- debug: Profiler Library initialized
2008-12-15 15:02:04 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-15 15:02:04 +01:00 --- debug: Database Library initialized
2008-12-15 16:17:11 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-15 16:17:11 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-15 16:17:11 +01:00 --- debug: Profiler Library initialized
2008-12-15 16:17:11 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-15 16:17:11 +01:00 --- debug: Database Library initialized
2008-12-15 16:17:52 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-15 16:17:52 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-15 16:17:52 +01:00 --- debug: Profiler Library initialized
2008-12-15 16:17:52 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-15 16:17:52 +01:00 --- debug: Database Library initialized
2008-12-15 16:18:41 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-15 16:18:41 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-15 16:18:41 +01:00 --- debug: Profiler Library initialized
2008-12-15 16:18:41 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-15 16:18:41 +01:00 --- debug: Database Library initialized
