<?php defined('SYSPATH') or die('No direct script access.'); ?>

2008-12-18 11:17:48 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 11:17:48 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 11:17:48 +01:00 --- debug: Profiler Library initialized
2008-12-18 11:17:48 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-18 11:17:48 +01:00 --- debug: Database Library initialized
2008-12-18 13:12:25 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 13:12:25 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 13:12:25 +01:00 --- debug: Profiler Library initialized
2008-12-18 13:12:25 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-18 13:12:25 +01:00 --- debug: Database Library initialized
2008-12-18 14:32:18 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 14:32:18 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 14:32:18 +01:00 --- debug: Profiler Library initialized
2008-12-18 14:32:18 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-18 14:32:18 +01:00 --- debug: Database Library initialized
2008-12-18 14:32:19 +01:00 --- error: Missing i18n entry resource.id for language cs_CZ
2008-12-18 14:32:19 +01:00 --- error: Missing i18n entry resource.curator_id for language cs_CZ
2008-12-18 14:32:19 +01:00 --- error: Missing i18n entry resource.contact_id for language cs_CZ
2008-12-18 14:32:19 +01:00 --- error: Missing i18n entry resource.publisher_id for language cs_CZ
2008-12-18 14:32:19 +01:00 --- error: Missing i18n entry resource.contract_id for language cs_CZ
2008-12-18 14:32:19 +01:00 --- error: Missing i18n entry resource.conspectus_id for language cs_CZ
2008-12-18 14:32:19 +01:00 --- error: Missing i18n entry resource.crawl_freq_id for language cs_CZ
2008-12-18 14:32:19 +01:00 --- error: Missing i18n entry resource.resource_status_id for language cs_CZ
2008-12-18 14:32:19 +01:00 --- error: Missing i18n entry resource.suggested_by_id for language cs_CZ
2008-12-18 14:32:19 +01:00 --- error: Missing i18n entry resource.title for language cs_CZ
2008-12-18 14:32:19 +01:00 --- error: Missing i18n entry resource.url for language cs_CZ
2008-12-18 14:32:19 +01:00 --- error: Missing i18n entry resource.rating_result for language cs_CZ
2008-12-18 14:32:19 +01:00 --- error: Missing i18n entry resource.date for language cs_CZ
2008-12-18 14:32:19 +01:00 --- error: Missing i18n entry resource.aleph_id for language cs_CZ
2008-12-18 14:32:19 +01:00 --- error: Missing i18n entry resource.ISSN for language cs_CZ
2008-12-18 14:32:19 +01:00 --- error: Missing i18n entry resource.metadata for language cs_CZ
2008-12-18 14:32:19 +01:00 --- error: Missing i18n entry resource.catalogued for language cs_CZ
2008-12-18 14:32:19 +01:00 --- error: Missing i18n entry resource.creative_commons for language cs_CZ
2008-12-18 14:32:19 +01:00 --- error: Missing i18n entry resource.tech_problems for language cs_CZ
2008-12-18 14:32:19 +01:00 --- error: Missing i18n entry resource.comments for language cs_CZ
2008-12-18 15:59:14 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 15:59:14 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 15:59:14 +01:00 --- debug: Profiler Library initialized
2008-12-18 15:59:14 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-18 15:59:14 +01:00 --- debug: Database Library initialized
2008-12-18 15:59:22 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 15:59:22 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 15:59:22 +01:00 --- debug: Profiler Library initialized
2008-12-18 15:59:22 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-18 15:59:22 +01:00 --- debug: Database Library initialized
2008-12-18 18:20:45 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 18:20:45 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 18:20:45 +01:00 --- debug: Profiler Library initialized
2008-12-18 18:20:46 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-18 18:20:46 +01:00 --- debug: Database Library initialized
2008-12-18 18:47:51 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 18:47:51 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 18:47:51 +01:00 --- debug: Profiler Library initialized
2008-12-18 18:47:51 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-18 18:47:51 +01:00 --- debug: Database Library initialized
2008-12-18 18:48:10 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 18:48:10 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 18:48:10 +01:00 --- debug: Profiler Library initialized
2008-12-18 18:48:10 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-18 18:48:10 +01:00 --- debug: Database Library initialized
2008-12-18 18:55:36 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 18:55:36 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 18:55:36 +01:00 --- debug: Profiler Library initialized
2008-12-18 18:55:36 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-18 18:55:36 +01:00 --- debug: Database Library initialized
2008-12-18 18:56:10 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 18:56:10 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 18:56:10 +01:00 --- debug: Profiler Library initialized
2008-12-18 18:56:10 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-18 18:56:10 +01:00 --- debug: Database Library initialized
2008-12-18 18:56:13 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 18:56:13 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 18:56:13 +01:00 --- debug: Profiler Library initialized
2008-12-18 18:56:13 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-18 18:56:13 +01:00 --- debug: Database Library initialized
2008-12-18 18:57:42 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 18:57:42 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 18:57:42 +01:00 --- debug: Profiler Library initialized
2008-12-18 18:57:42 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-18 18:57:42 +01:00 --- debug: Database Library initialized
2008-12-18 18:58:26 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 18:58:26 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 18:58:26 +01:00 --- debug: Profiler Library initialized
2008-12-18 18:58:26 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-18 18:58:26 +01:00 --- debug: Database Library initialized
2008-12-18 18:59:56 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 18:59:56 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 18:59:56 +01:00 --- debug: Profiler Library initialized
2008-12-18 18:59:56 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-18 18:59:56 +01:00 --- debug: Database Library initialized
2008-12-18 19:10:31 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 19:10:31 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 19:10:31 +01:00 --- debug: Profiler Library initialized
2008-12-18 19:10:31 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-18 19:10:31 +01:00 --- debug: Database Library initialized
2008-12-18 19:10:51 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 19:10:51 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 19:10:51 +01:00 --- debug: Profiler Library initialized
2008-12-18 19:10:51 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-18 19:10:51 +01:00 --- debug: Database Library initialized
2008-12-18 19:11:00 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 19:11:00 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 19:11:00 +01:00 --- debug: Profiler Library initialized
2008-12-18 19:11:00 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-18 19:11:00 +01:00 --- debug: Database Library initialized
2008-12-18 19:11:12 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 19:11:12 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 19:11:12 +01:00 --- debug: Profiler Library initialized
2008-12-18 19:11:12 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-18 19:11:12 +01:00 --- debug: Database Library initialized
2008-12-18 19:11:55 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 19:11:55 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 19:11:55 +01:00 --- debug: Profiler Library initialized
2008-12-18 19:11:56 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-18 19:11:56 +01:00 --- debug: Database Library initialized
2008-12-18 19:11:57 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 19:11:58 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 19:11:58 +01:00 --- debug: Profiler Library initialized
2008-12-18 19:11:58 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-18 19:11:58 +01:00 --- debug: Database Library initialized
2008-12-18 19:11:58 +01:00 --- error: Missing i18n entry resource.id for language cs_CZ
2008-12-18 19:11:58 +01:00 --- error: Missing i18n entry resource.curator_id for language cs_CZ
2008-12-18 19:11:58 +01:00 --- error: Missing i18n entry resource.contact_id for language cs_CZ
2008-12-18 19:11:58 +01:00 --- error: Missing i18n entry resource.publisher_id for language cs_CZ
2008-12-18 19:11:58 +01:00 --- error: Missing i18n entry resource.contract_id for language cs_CZ
2008-12-18 19:11:58 +01:00 --- error: Missing i18n entry resource.conspectus_id for language cs_CZ
2008-12-18 19:11:58 +01:00 --- error: Missing i18n entry resource.crawl_freq_id for language cs_CZ
2008-12-18 19:11:58 +01:00 --- error: Missing i18n entry resource.resource_status_id for language cs_CZ
2008-12-18 19:11:58 +01:00 --- error: Missing i18n entry resource.suggested_by_id for language cs_CZ
2008-12-18 19:11:58 +01:00 --- error: Missing i18n entry resource.title for language cs_CZ
2008-12-18 19:11:58 +01:00 --- error: Missing i18n entry resource.url for language cs_CZ
2008-12-18 19:11:58 +01:00 --- error: Missing i18n entry resource.rating_result for language cs_CZ
2008-12-18 19:11:58 +01:00 --- error: Missing i18n entry resource.date for language cs_CZ
2008-12-18 19:11:58 +01:00 --- error: Missing i18n entry resource.aleph_id for language cs_CZ
2008-12-18 19:11:58 +01:00 --- error: Missing i18n entry resource.ISSN for language cs_CZ
2008-12-18 19:11:58 +01:00 --- error: Missing i18n entry resource.metadata for language cs_CZ
2008-12-18 19:11:58 +01:00 --- error: Missing i18n entry resource.catalogued for language cs_CZ
2008-12-18 19:11:58 +01:00 --- error: Missing i18n entry resource.creative_commons for language cs_CZ
2008-12-18 19:11:58 +01:00 --- error: Missing i18n entry resource.tech_problems for language cs_CZ
2008-12-18 19:11:58 +01:00 --- error: Missing i18n entry resource.comments for language cs_CZ
2008-12-18 21:03:25 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 21:03:25 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 21:03:25 +01:00 --- debug: Profiler Library initialized
2008-12-18 21:03:25 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-18 21:03:25 +01:00 --- debug: Database Library initialized
2008-12-18 21:04:35 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 21:04:35 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 21:04:35 +01:00 --- debug: Profiler Library initialized
2008-12-18 21:04:35 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-18 21:04:35 +01:00 --- debug: Database Library initialized
2008-12-18 21:04:37 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 21:04:37 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 21:04:37 +01:00 --- debug: Profiler Library initialized
2008-12-18 21:04:37 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-18 21:04:37 +01:00 --- debug: Database Library initialized
2008-12-18 21:05:05 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 21:05:05 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 21:05:05 +01:00 --- debug: Profiler Library initialized
2008-12-18 21:05:05 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-18 21:05:05 +01:00 --- debug: Database Library initialized
2008-12-18 21:06:14 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 21:06:14 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 21:06:14 +01:00 --- debug: Profiler Library initialized
2008-12-18 21:06:14 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-18 21:06:14 +01:00 --- debug: Database Library initialized
2008-12-18 21:06:36 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 21:06:36 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 21:06:36 +01:00 --- debug: Profiler Library initialized
2008-12-18 21:06:36 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-18 21:06:36 +01:00 --- debug: Database Library initialized
2008-12-18 21:06:54 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 21:06:54 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 21:06:54 +01:00 --- debug: Profiler Library initialized
2008-12-18 21:06:54 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-18 21:06:54 +01:00 --- debug: Database Library initialized
2008-12-18 21:07:00 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 21:07:00 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 21:07:00 +01:00 --- debug: Profiler Library initialized
2008-12-18 21:07:02 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 21:07:02 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 21:07:02 +01:00 --- debug: Profiler Library initialized
2008-12-18 21:07:02 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-18 21:07:02 +01:00 --- debug: Database Library initialized
2008-12-18 21:08:32 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 21:08:32 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 21:08:32 +01:00 --- debug: Profiler Library initialized
2008-12-18 21:08:32 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-18 21:08:32 +01:00 --- debug: Database Library initialized
2008-12-18 21:08:51 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 21:08:51 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 21:08:51 +01:00 --- debug: Profiler Library initialized
2008-12-18 21:08:51 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-18 21:08:51 +01:00 --- debug: Database Library initialized
2008-12-18 21:08:52 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 21:08:52 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 21:08:52 +01:00 --- debug: Profiler Library initialized
2008-12-18 21:08:52 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-18 21:08:52 +01:00 --- debug: Database Library initialized
2008-12-18 21:17:36 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 21:17:36 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 21:17:36 +01:00 --- debug: Profiler Library initialized
2008-12-18 21:17:36 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-18 21:17:36 +01:00 --- debug: Database Library initialized
2008-12-18 21:17:50 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 21:17:50 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 21:17:50 +01:00 --- debug: Profiler Library initialized
2008-12-18 21:17:50 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-18 21:17:50 +01:00 --- debug: Database Library initialized
2008-12-18 21:24:07 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 21:24:07 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 21:24:07 +01:00 --- debug: Profiler Library initialized
2008-12-18 21:24:07 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-18 21:24:07 +01:00 --- debug: Database Library initialized
2008-12-18 21:24:29 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 21:24:29 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 21:24:29 +01:00 --- debug: Profiler Library initialized
2008-12-18 21:24:29 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-18 21:24:29 +01:00 --- debug: Database Library initialized
2008-12-18 21:25:13 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 21:25:13 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 21:25:13 +01:00 --- debug: Profiler Library initialized
2008-12-18 21:25:13 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-18 21:25:13 +01:00 --- debug: Database Library initialized
2008-12-18 21:25:25 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 21:25:25 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 21:25:25 +01:00 --- debug: Profiler Library initialized
2008-12-18 21:25:25 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-18 21:25:25 +01:00 --- debug: Database Library initialized
2008-12-18 21:25:44 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 21:25:44 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 21:25:44 +01:00 --- debug: Profiler Library initialized
2008-12-18 21:25:44 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-18 21:25:44 +01:00 --- debug: Database Library initialized
2008-12-18 21:43:10 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 21:43:10 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 21:43:10 +01:00 --- debug: Profiler Library initialized
2008-12-18 21:43:10 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-18 21:43:10 +01:00 --- debug: Database Library initialized
2008-12-18 21:43:11 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 21:43:11 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 21:43:11 +01:00 --- debug: Profiler Library initialized
2008-12-18 21:43:11 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-18 21:43:11 +01:00 --- debug: Database Library initialized
2008-12-18 21:43:24 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 21:43:24 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 21:43:24 +01:00 --- debug: Profiler Library initialized
2008-12-18 21:43:24 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-18 21:43:24 +01:00 --- debug: Database Library initialized
2008-12-18 21:44:00 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 21:44:00 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 21:44:00 +01:00 --- debug: Profiler Library initialized
2008-12-18 21:44:00 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-18 21:44:00 +01:00 --- debug: Database Library initialized
2008-12-18 21:44:00 +01:00 --- error: Missing i18n entry validation.contract_no for language cs_CZ
2008-12-18 21:44:54 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 21:44:54 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 21:44:54 +01:00 --- debug: Profiler Library initialized
2008-12-18 21:44:54 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-18 21:44:54 +01:00 --- debug: Database Library initialized
2008-12-18 21:44:54 +01:00 --- error: Missing i18n entry validation.contract_no for language cs_CZ
2008-12-18 21:44:57 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 21:44:57 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 21:44:57 +01:00 --- debug: Profiler Library initialized
2008-12-18 21:44:57 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-18 21:44:57 +01:00 --- debug: Database Library initialized
2008-12-18 21:45:39 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 21:45:39 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 21:45:40 +01:00 --- debug: Profiler Library initialized
2008-12-18 21:45:40 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-18 21:45:40 +01:00 --- debug: Database Library initialized
2008-12-18 21:48:40 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 21:48:40 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 21:48:40 +01:00 --- debug: Profiler Library initialized
2008-12-18 21:48:40 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-18 21:48:40 +01:00 --- debug: Database Library initialized
2008-12-18 21:53:23 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 21:53:23 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 21:53:23 +01:00 --- debug: Profiler Library initialized
2008-12-18 21:53:23 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-18 21:53:23 +01:00 --- debug: Database Library initialized
2008-12-18 21:54:00 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 21:54:00 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 21:54:00 +01:00 --- debug: Profiler Library initialized
2008-12-18 21:54:00 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-18 21:54:00 +01:00 --- debug: Database Library initialized
2008-12-18 21:54:41 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 21:54:41 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 21:54:41 +01:00 --- debug: Profiler Library initialized
2008-12-18 21:54:41 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-18 21:54:41 +01:00 --- debug: Database Library initialized
2008-12-18 21:54:41 +01:00 --- error: Missing i18n entry resource.id for language cs_CZ
2008-12-18 21:54:41 +01:00 --- error: Missing i18n entry resource.curator_id for language cs_CZ
2008-12-18 21:54:41 +01:00 --- error: Missing i18n entry resource.contact_id for language cs_CZ
2008-12-18 21:54:41 +01:00 --- error: Missing i18n entry resource.publisher_id for language cs_CZ
2008-12-18 21:54:41 +01:00 --- error: Missing i18n entry resource.contract_id for language cs_CZ
2008-12-18 21:54:41 +01:00 --- error: Missing i18n entry resource.conspectus_id for language cs_CZ
2008-12-18 21:54:41 +01:00 --- error: Missing i18n entry resource.crawl_freq_id for language cs_CZ
2008-12-18 21:54:41 +01:00 --- error: Missing i18n entry resource.resource_status_id for language cs_CZ
2008-12-18 21:54:41 +01:00 --- error: Missing i18n entry resource.suggested_by_id for language cs_CZ
2008-12-18 21:54:41 +01:00 --- error: Missing i18n entry resource.title for language cs_CZ
2008-12-18 21:54:41 +01:00 --- error: Missing i18n entry resource.url for language cs_CZ
2008-12-18 21:54:41 +01:00 --- error: Missing i18n entry resource.rating_result for language cs_CZ
2008-12-18 21:54:41 +01:00 --- error: Missing i18n entry resource.date for language cs_CZ
2008-12-18 21:54:41 +01:00 --- error: Missing i18n entry resource.aleph_id for language cs_CZ
2008-12-18 21:54:41 +01:00 --- error: Missing i18n entry resource.ISSN for language cs_CZ
2008-12-18 21:54:41 +01:00 --- error: Missing i18n entry resource.metadata for language cs_CZ
2008-12-18 21:54:41 +01:00 --- error: Missing i18n entry resource.catalogued for language cs_CZ
2008-12-18 21:54:41 +01:00 --- error: Missing i18n entry resource.creative_commons for language cs_CZ
2008-12-18 21:54:41 +01:00 --- error: Missing i18n entry resource.tech_problems for language cs_CZ
2008-12-18 21:54:41 +01:00 --- error: Missing i18n entry resource.comments for language cs_CZ
2008-12-18 21:54:53 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 21:54:53 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 21:54:53 +01:00 --- debug: Profiler Library initialized
2008-12-18 21:54:53 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-18 21:54:53 +01:00 --- debug: Database Library initialized
2008-12-18 21:54:53 +01:00 --- error: Missing i18n entry validation.contract_no for language cs_CZ
2008-12-18 21:54:58 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 21:54:58 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 21:54:58 +01:00 --- debug: Profiler Library initialized
2008-12-18 21:54:58 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-18 21:54:58 +01:00 --- debug: Database Library initialized
2008-12-18 21:54:58 +01:00 --- error: Missing i18n entry resource.id for language cs_CZ
2008-12-18 21:54:58 +01:00 --- error: Missing i18n entry resource.curator_id for language cs_CZ
2008-12-18 21:54:58 +01:00 --- error: Missing i18n entry resource.contact_id for language cs_CZ
2008-12-18 21:54:58 +01:00 --- error: Missing i18n entry resource.publisher_id for language cs_CZ
2008-12-18 21:54:58 +01:00 --- error: Missing i18n entry resource.contract_id for language cs_CZ
2008-12-18 21:54:58 +01:00 --- error: Missing i18n entry resource.conspectus_id for language cs_CZ
2008-12-18 21:54:58 +01:00 --- error: Missing i18n entry resource.crawl_freq_id for language cs_CZ
2008-12-18 21:54:58 +01:00 --- error: Missing i18n entry resource.resource_status_id for language cs_CZ
2008-12-18 21:54:58 +01:00 --- error: Missing i18n entry resource.suggested_by_id for language cs_CZ
2008-12-18 21:54:58 +01:00 --- error: Missing i18n entry resource.title for language cs_CZ
2008-12-18 21:54:58 +01:00 --- error: Missing i18n entry resource.url for language cs_CZ
2008-12-18 21:54:58 +01:00 --- error: Missing i18n entry resource.rating_result for language cs_CZ
2008-12-18 21:54:58 +01:00 --- error: Missing i18n entry resource.date for language cs_CZ
2008-12-18 21:54:58 +01:00 --- error: Missing i18n entry resource.aleph_id for language cs_CZ
2008-12-18 21:54:58 +01:00 --- error: Missing i18n entry resource.ISSN for language cs_CZ
2008-12-18 21:54:58 +01:00 --- error: Missing i18n entry resource.metadata for language cs_CZ
2008-12-18 21:54:58 +01:00 --- error: Missing i18n entry resource.catalogued for language cs_CZ
2008-12-18 21:54:58 +01:00 --- error: Missing i18n entry resource.creative_commons for language cs_CZ
2008-12-18 21:54:58 +01:00 --- error: Missing i18n entry resource.tech_problems for language cs_CZ
2008-12-18 21:54:58 +01:00 --- error: Missing i18n entry resource.comments for language cs_CZ
2008-12-18 21:55:05 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 21:55:05 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 21:55:05 +01:00 --- debug: Profiler Library initialized
2008-12-18 21:55:05 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-18 21:55:05 +01:00 --- debug: Database Library initialized
2008-12-18 21:55:05 +01:00 --- error: Missing i18n entry resource.id for language cs_CZ
2008-12-18 21:55:05 +01:00 --- error: Missing i18n entry resource.curator_id for language cs_CZ
2008-12-18 21:55:05 +01:00 --- error: Missing i18n entry resource.contact_id for language cs_CZ
2008-12-18 21:55:05 +01:00 --- error: Missing i18n entry resource.publisher_id for language cs_CZ
2008-12-18 21:55:05 +01:00 --- error: Missing i18n entry resource.contract_id for language cs_CZ
2008-12-18 21:55:05 +01:00 --- error: Missing i18n entry resource.conspectus_id for language cs_CZ
2008-12-18 21:55:05 +01:00 --- error: Missing i18n entry resource.crawl_freq_id for language cs_CZ
2008-12-18 21:55:05 +01:00 --- error: Missing i18n entry resource.resource_status_id for language cs_CZ
2008-12-18 21:55:05 +01:00 --- error: Missing i18n entry resource.suggested_by_id for language cs_CZ
2008-12-18 21:55:05 +01:00 --- error: Missing i18n entry resource.title for language cs_CZ
2008-12-18 21:55:05 +01:00 --- error: Missing i18n entry resource.url for language cs_CZ
2008-12-18 21:55:05 +01:00 --- error: Missing i18n entry resource.rating_result for language cs_CZ
2008-12-18 21:55:05 +01:00 --- error: Missing i18n entry resource.date for language cs_CZ
2008-12-18 21:55:05 +01:00 --- error: Missing i18n entry resource.aleph_id for language cs_CZ
2008-12-18 21:55:05 +01:00 --- error: Missing i18n entry resource.ISSN for language cs_CZ
2008-12-18 21:55:05 +01:00 --- error: Missing i18n entry resource.metadata for language cs_CZ
2008-12-18 21:55:05 +01:00 --- error: Missing i18n entry resource.catalogued for language cs_CZ
2008-12-18 21:55:05 +01:00 --- error: Missing i18n entry resource.creative_commons for language cs_CZ
2008-12-18 21:55:05 +01:00 --- error: Missing i18n entry resource.tech_problems for language cs_CZ
2008-12-18 21:55:05 +01:00 --- error: Missing i18n entry resource.comments for language cs_CZ
2008-12-18 21:55:19 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 21:55:19 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 21:55:19 +01:00 --- debug: Profiler Library initialized
2008-12-18 21:55:19 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-18 21:55:19 +01:00 --- debug: Database Library initialized
2008-12-18 21:55:19 +01:00 --- error: Missing i18n entry resource.id for language cs_CZ
2008-12-18 21:55:19 +01:00 --- error: Missing i18n entry resource.curator_id for language cs_CZ
2008-12-18 21:55:19 +01:00 --- error: Missing i18n entry resource.contact_id for language cs_CZ
2008-12-18 21:55:19 +01:00 --- error: Missing i18n entry resource.publisher_id for language cs_CZ
2008-12-18 21:55:19 +01:00 --- error: Missing i18n entry resource.contract_id for language cs_CZ
2008-12-18 21:55:19 +01:00 --- error: Missing i18n entry resource.conspectus_id for language cs_CZ
2008-12-18 21:55:19 +01:00 --- error: Missing i18n entry resource.crawl_freq_id for language cs_CZ
2008-12-18 21:55:19 +01:00 --- error: Missing i18n entry resource.resource_status_id for language cs_CZ
2008-12-18 21:55:19 +01:00 --- error: Missing i18n entry resource.suggested_by_id for language cs_CZ
2008-12-18 21:55:19 +01:00 --- error: Missing i18n entry resource.title for language cs_CZ
2008-12-18 21:55:19 +01:00 --- error: Missing i18n entry resource.url for language cs_CZ
2008-12-18 21:55:19 +01:00 --- error: Missing i18n entry resource.rating_result for language cs_CZ
2008-12-18 21:55:19 +01:00 --- error: Missing i18n entry resource.date for language cs_CZ
2008-12-18 21:55:19 +01:00 --- error: Missing i18n entry resource.aleph_id for language cs_CZ
2008-12-18 21:55:19 +01:00 --- error: Missing i18n entry resource.ISSN for language cs_CZ
2008-12-18 21:55:19 +01:00 --- error: Missing i18n entry resource.metadata for language cs_CZ
2008-12-18 21:55:19 +01:00 --- error: Missing i18n entry resource.catalogued for language cs_CZ
2008-12-18 21:55:19 +01:00 --- error: Missing i18n entry resource.creative_commons for language cs_CZ
2008-12-18 21:55:19 +01:00 --- error: Missing i18n entry resource.tech_problems for language cs_CZ
2008-12-18 21:55:19 +01:00 --- error: Missing i18n entry resource.comments for language cs_CZ
2008-12-18 21:56:49 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 21:56:49 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 21:56:49 +01:00 --- debug: Profiler Library initialized
2008-12-18 21:56:49 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-18 21:56:49 +01:00 --- debug: Database Library initialized
2008-12-18 21:57:09 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 21:57:09 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 21:57:09 +01:00 --- debug: Profiler Library initialized
2008-12-18 21:57:09 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-18 21:57:09 +01:00 --- debug: Database Library initialized
2008-12-18 21:57:09 +01:00 --- error: Missing i18n entry resource.id for language cs_CZ
2008-12-18 21:57:09 +01:00 --- error: Missing i18n entry resource.curator_id for language cs_CZ
2008-12-18 21:57:09 +01:00 --- error: Missing i18n entry resource.contact_id for language cs_CZ
2008-12-18 21:57:09 +01:00 --- error: Missing i18n entry resource.publisher_id for language cs_CZ
2008-12-18 21:57:09 +01:00 --- error: Missing i18n entry resource.contract_id for language cs_CZ
2008-12-18 21:57:09 +01:00 --- error: Missing i18n entry resource.conspectus_id for language cs_CZ
2008-12-18 21:57:09 +01:00 --- error: Missing i18n entry resource.crawl_freq_id for language cs_CZ
2008-12-18 21:57:09 +01:00 --- error: Missing i18n entry resource.resource_status_id for language cs_CZ
2008-12-18 21:57:09 +01:00 --- error: Missing i18n entry resource.suggested_by_id for language cs_CZ
2008-12-18 21:57:09 +01:00 --- error: Missing i18n entry resource.title for language cs_CZ
2008-12-18 21:57:09 +01:00 --- error: Missing i18n entry resource.url for language cs_CZ
2008-12-18 21:57:09 +01:00 --- error: Missing i18n entry resource.rating_result for language cs_CZ
2008-12-18 21:57:09 +01:00 --- error: Missing i18n entry resource.date for language cs_CZ
2008-12-18 21:57:09 +01:00 --- error: Missing i18n entry resource.aleph_id for language cs_CZ
2008-12-18 21:57:09 +01:00 --- error: Missing i18n entry resource.ISSN for language cs_CZ
2008-12-18 21:57:09 +01:00 --- error: Missing i18n entry resource.metadata for language cs_CZ
2008-12-18 21:57:09 +01:00 --- error: Missing i18n entry resource.catalogued for language cs_CZ
2008-12-18 21:57:09 +01:00 --- error: Missing i18n entry resource.creative_commons for language cs_CZ
2008-12-18 21:57:09 +01:00 --- error: Missing i18n entry resource.tech_problems for language cs_CZ
2008-12-18 21:57:09 +01:00 --- error: Missing i18n entry resource.comments for language cs_CZ
2008-12-18 22:01:49 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 22:01:49 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 22:01:49 +01:00 --- debug: Profiler Library initialized
2008-12-18 22:01:49 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-18 22:01:49 +01:00 --- debug: Database Library initialized
2008-12-18 22:01:49 +01:00 --- error: Missing i18n entry resource.id for language cs_CZ
2008-12-18 22:01:49 +01:00 --- error: Missing i18n entry resource.curator_id for language cs_CZ
2008-12-18 22:01:49 +01:00 --- error: Missing i18n entry resource.contact_id for language cs_CZ
2008-12-18 22:01:49 +01:00 --- error: Missing i18n entry resource.publisher_id for language cs_CZ
2008-12-18 22:01:49 +01:00 --- error: Missing i18n entry resource.contract_id for language cs_CZ
2008-12-18 22:01:49 +01:00 --- error: Missing i18n entry resource.conspectus_id for language cs_CZ
2008-12-18 22:01:49 +01:00 --- error: Missing i18n entry resource.crawl_freq_id for language cs_CZ
2008-12-18 22:01:49 +01:00 --- error: Missing i18n entry resource.resource_status_id for language cs_CZ
2008-12-18 22:01:49 +01:00 --- error: Missing i18n entry resource.suggested_by_id for language cs_CZ
2008-12-18 22:01:49 +01:00 --- error: Missing i18n entry resource.title for language cs_CZ
2008-12-18 22:01:49 +01:00 --- error: Missing i18n entry resource.url for language cs_CZ
2008-12-18 22:01:49 +01:00 --- error: Missing i18n entry resource.rating_result for language cs_CZ
2008-12-18 22:01:49 +01:00 --- error: Missing i18n entry resource.date for language cs_CZ
2008-12-18 22:01:49 +01:00 --- error: Missing i18n entry resource.aleph_id for language cs_CZ
2008-12-18 22:01:49 +01:00 --- error: Missing i18n entry resource.ISSN for language cs_CZ
2008-12-18 22:01:49 +01:00 --- error: Missing i18n entry resource.metadata for language cs_CZ
2008-12-18 22:01:49 +01:00 --- error: Missing i18n entry resource.catalogued for language cs_CZ
2008-12-18 22:01:49 +01:00 --- error: Missing i18n entry resource.creative_commons for language cs_CZ
2008-12-18 22:01:49 +01:00 --- error: Missing i18n entry resource.tech_problems for language cs_CZ
2008-12-18 22:01:49 +01:00 --- error: Missing i18n entry resource.comments for language cs_CZ
2008-12-18 22:01:51 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 22:01:51 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 22:01:51 +01:00 --- debug: Profiler Library initialized
2008-12-18 22:01:51 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-18 22:01:51 +01:00 --- debug: Database Library initialized
2008-12-18 22:01:51 +01:00 --- error: Missing i18n entry resource.id for language cs_CZ
2008-12-18 22:01:51 +01:00 --- error: Missing i18n entry resource.curator_id for language cs_CZ
2008-12-18 22:01:51 +01:00 --- error: Missing i18n entry resource.contact_id for language cs_CZ
2008-12-18 22:01:51 +01:00 --- error: Missing i18n entry resource.publisher_id for language cs_CZ
2008-12-18 22:01:51 +01:00 --- error: Missing i18n entry resource.contract_id for language cs_CZ
2008-12-18 22:01:51 +01:00 --- error: Missing i18n entry resource.conspectus_id for language cs_CZ
2008-12-18 22:01:51 +01:00 --- error: Missing i18n entry resource.crawl_freq_id for language cs_CZ
2008-12-18 22:01:51 +01:00 --- error: Missing i18n entry resource.resource_status_id for language cs_CZ
2008-12-18 22:01:51 +01:00 --- error: Missing i18n entry resource.suggested_by_id for language cs_CZ
2008-12-18 22:01:51 +01:00 --- error: Missing i18n entry resource.title for language cs_CZ
2008-12-18 22:01:51 +01:00 --- error: Missing i18n entry resource.url for language cs_CZ
2008-12-18 22:01:51 +01:00 --- error: Missing i18n entry resource.rating_result for language cs_CZ
2008-12-18 22:01:51 +01:00 --- error: Missing i18n entry resource.date for language cs_CZ
2008-12-18 22:01:51 +01:00 --- error: Missing i18n entry resource.aleph_id for language cs_CZ
2008-12-18 22:01:51 +01:00 --- error: Missing i18n entry resource.ISSN for language cs_CZ
2008-12-18 22:01:51 +01:00 --- error: Missing i18n entry resource.metadata for language cs_CZ
2008-12-18 22:01:51 +01:00 --- error: Missing i18n entry resource.catalogued for language cs_CZ
2008-12-18 22:01:51 +01:00 --- error: Missing i18n entry resource.creative_commons for language cs_CZ
2008-12-18 22:01:51 +01:00 --- error: Missing i18n entry resource.tech_problems for language cs_CZ
2008-12-18 22:01:51 +01:00 --- error: Missing i18n entry resource.comments for language cs_CZ
2008-12-18 22:08:32 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 22:08:32 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 22:08:32 +01:00 --- debug: Profiler Library initialized
2008-12-18 22:08:32 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-18 22:08:32 +01:00 --- debug: Database Library initialized
2008-12-18 22:08:43 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 22:08:43 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 22:08:43 +01:00 --- debug: Profiler Library initialized
2008-12-18 22:08:43 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-18 22:08:43 +01:00 --- debug: Database Library initialized
2008-12-18 22:10:20 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 22:10:20 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 22:10:20 +01:00 --- debug: Profiler Library initialized
2008-12-18 22:10:20 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-18 22:10:20 +01:00 --- debug: Database Library initialized
2008-12-18 22:10:43 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 22:10:43 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 22:10:43 +01:00 --- debug: Profiler Library initialized
2008-12-18 22:10:43 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-18 22:10:43 +01:00 --- debug: Database Library initialized
2008-12-18 22:10:55 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 22:10:55 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 22:10:55 +01:00 --- debug: Profiler Library initialized
2008-12-18 22:10:55 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-18 22:10:55 +01:00 --- debug: Database Library initialized
2008-12-18 22:10:55 +01:00 --- error: Missing i18n entry resource.id for language cs_CZ
2008-12-18 22:10:55 +01:00 --- error: Missing i18n entry resource.curator_id for language cs_CZ
2008-12-18 22:10:55 +01:00 --- error: Missing i18n entry resource.contact_id for language cs_CZ
2008-12-18 22:10:55 +01:00 --- error: Missing i18n entry resource.publisher_id for language cs_CZ
2008-12-18 22:10:55 +01:00 --- error: Missing i18n entry resource.contract_id for language cs_CZ
2008-12-18 22:10:55 +01:00 --- error: Missing i18n entry resource.conspectus_id for language cs_CZ
2008-12-18 22:10:55 +01:00 --- error: Missing i18n entry resource.crawl_freq_id for language cs_CZ
2008-12-18 22:10:55 +01:00 --- error: Missing i18n entry resource.resource_status_id for language cs_CZ
2008-12-18 22:10:55 +01:00 --- error: Missing i18n entry resource.suggested_by_id for language cs_CZ
2008-12-18 22:10:55 +01:00 --- error: Missing i18n entry resource.title for language cs_CZ
2008-12-18 22:10:55 +01:00 --- error: Missing i18n entry resource.url for language cs_CZ
2008-12-18 22:10:55 +01:00 --- error: Missing i18n entry resource.rating_result for language cs_CZ
2008-12-18 22:10:55 +01:00 --- error: Missing i18n entry resource.date for language cs_CZ
2008-12-18 22:10:55 +01:00 --- error: Missing i18n entry resource.aleph_id for language cs_CZ
2008-12-18 22:10:55 +01:00 --- error: Missing i18n entry resource.ISSN for language cs_CZ
2008-12-18 22:10:55 +01:00 --- error: Missing i18n entry resource.metadata for language cs_CZ
2008-12-18 22:10:55 +01:00 --- error: Missing i18n entry resource.catalogued for language cs_CZ
2008-12-18 22:10:55 +01:00 --- error: Missing i18n entry resource.creative_commons for language cs_CZ
2008-12-18 22:10:55 +01:00 --- error: Missing i18n entry resource.tech_problems for language cs_CZ
2008-12-18 22:10:55 +01:00 --- error: Missing i18n entry resource.comments for language cs_CZ
2008-12-18 22:11:31 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 22:11:31 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 22:11:31 +01:00 --- debug: Profiler Library initialized
2008-12-18 22:11:31 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-18 22:11:31 +01:00 --- debug: Database Library initialized
2008-12-18 22:11:31 +01:00 --- error: Missing i18n entry resource.id for language cs_CZ
2008-12-18 22:11:31 +01:00 --- error: Missing i18n entry resource.curator_id for language cs_CZ
2008-12-18 22:11:31 +01:00 --- error: Missing i18n entry resource.contact_id for language cs_CZ
2008-12-18 22:11:31 +01:00 --- error: Missing i18n entry resource.publisher_id for language cs_CZ
2008-12-18 22:11:31 +01:00 --- error: Missing i18n entry resource.contract_id for language cs_CZ
2008-12-18 22:11:31 +01:00 --- error: Missing i18n entry resource.conspectus_id for language cs_CZ
2008-12-18 22:11:31 +01:00 --- error: Missing i18n entry resource.crawl_freq_id for language cs_CZ
2008-12-18 22:11:31 +01:00 --- error: Missing i18n entry resource.resource_status_id for language cs_CZ
2008-12-18 22:11:31 +01:00 --- error: Missing i18n entry resource.suggested_by_id for language cs_CZ
2008-12-18 22:11:31 +01:00 --- error: Missing i18n entry resource.title for language cs_CZ
2008-12-18 22:11:31 +01:00 --- error: Missing i18n entry resource.url for language cs_CZ
2008-12-18 22:11:31 +01:00 --- error: Missing i18n entry resource.rating_result for language cs_CZ
2008-12-18 22:11:31 +01:00 --- error: Missing i18n entry resource.date for language cs_CZ
2008-12-18 22:11:31 +01:00 --- error: Missing i18n entry resource.aleph_id for language cs_CZ
2008-12-18 22:11:31 +01:00 --- error: Missing i18n entry resource.ISSN for language cs_CZ
2008-12-18 22:11:31 +01:00 --- error: Missing i18n entry resource.metadata for language cs_CZ
2008-12-18 22:11:31 +01:00 --- error: Missing i18n entry resource.catalogued for language cs_CZ
2008-12-18 22:11:31 +01:00 --- error: Missing i18n entry resource.creative_commons for language cs_CZ
2008-12-18 22:11:31 +01:00 --- error: Missing i18n entry resource.tech_problems for language cs_CZ
2008-12-18 22:11:31 +01:00 --- error: Missing i18n entry resource.comments for language cs_CZ
2008-12-18 22:11:33 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 22:11:33 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 22:11:33 +01:00 --- debug: Profiler Library initialized
2008-12-18 22:11:33 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-18 22:11:33 +01:00 --- debug: Database Library initialized
2008-12-18 22:11:33 +01:00 --- error: Missing i18n entry resource.id for language cs_CZ
2008-12-18 22:11:33 +01:00 --- error: Missing i18n entry resource.curator_id for language cs_CZ
2008-12-18 22:11:33 +01:00 --- error: Missing i18n entry resource.contact_id for language cs_CZ
2008-12-18 22:11:33 +01:00 --- error: Missing i18n entry resource.publisher_id for language cs_CZ
2008-12-18 22:11:33 +01:00 --- error: Missing i18n entry resource.contract_id for language cs_CZ
2008-12-18 22:11:33 +01:00 --- error: Missing i18n entry resource.conspectus_id for language cs_CZ
2008-12-18 22:11:33 +01:00 --- error: Missing i18n entry resource.crawl_freq_id for language cs_CZ
2008-12-18 22:11:33 +01:00 --- error: Missing i18n entry resource.resource_status_id for language cs_CZ
2008-12-18 22:11:33 +01:00 --- error: Missing i18n entry resource.suggested_by_id for language cs_CZ
2008-12-18 22:11:33 +01:00 --- error: Missing i18n entry resource.title for language cs_CZ
2008-12-18 22:11:33 +01:00 --- error: Missing i18n entry resource.url for language cs_CZ
2008-12-18 22:11:33 +01:00 --- error: Missing i18n entry resource.rating_result for language cs_CZ
2008-12-18 22:11:33 +01:00 --- error: Missing i18n entry resource.date for language cs_CZ
2008-12-18 22:11:33 +01:00 --- error: Missing i18n entry resource.aleph_id for language cs_CZ
2008-12-18 22:11:33 +01:00 --- error: Missing i18n entry resource.ISSN for language cs_CZ
2008-12-18 22:11:33 +01:00 --- error: Missing i18n entry resource.metadata for language cs_CZ
2008-12-18 22:11:33 +01:00 --- error: Missing i18n entry resource.catalogued for language cs_CZ
2008-12-18 22:11:33 +01:00 --- error: Missing i18n entry resource.creative_commons for language cs_CZ
2008-12-18 22:11:33 +01:00 --- error: Missing i18n entry resource.tech_problems for language cs_CZ
2008-12-18 22:11:33 +01:00 --- error: Missing i18n entry resource.comments for language cs_CZ
2008-12-18 22:12:02 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 22:12:02 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 22:12:02 +01:00 --- debug: Profiler Library initialized
2008-12-18 22:12:02 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-18 22:12:02 +01:00 --- debug: Database Library initialized
2008-12-18 22:12:07 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 22:12:07 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 22:12:07 +01:00 --- debug: Profiler Library initialized
2008-12-18 22:12:07 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-18 22:12:07 +01:00 --- debug: Database Library initialized
2008-12-18 22:12:07 +01:00 --- error: Missing i18n entry resource.id for language cs_CZ
2008-12-18 22:12:07 +01:00 --- error: Missing i18n entry resource.curator_id for language cs_CZ
2008-12-18 22:12:07 +01:00 --- error: Missing i18n entry resource.contact_id for language cs_CZ
2008-12-18 22:12:07 +01:00 --- error: Missing i18n entry resource.publisher_id for language cs_CZ
2008-12-18 22:12:07 +01:00 --- error: Missing i18n entry resource.contract_id for language cs_CZ
2008-12-18 22:12:07 +01:00 --- error: Missing i18n entry resource.conspectus_id for language cs_CZ
2008-12-18 22:12:07 +01:00 --- error: Missing i18n entry resource.crawl_freq_id for language cs_CZ
2008-12-18 22:12:07 +01:00 --- error: Missing i18n entry resource.resource_status_id for language cs_CZ
2008-12-18 22:12:07 +01:00 --- error: Missing i18n entry resource.suggested_by_id for language cs_CZ
2008-12-18 22:12:07 +01:00 --- error: Missing i18n entry resource.title for language cs_CZ
2008-12-18 22:12:07 +01:00 --- error: Missing i18n entry resource.url for language cs_CZ
2008-12-18 22:12:07 +01:00 --- error: Missing i18n entry resource.rating_result for language cs_CZ
2008-12-18 22:12:07 +01:00 --- error: Missing i18n entry resource.date for language cs_CZ
2008-12-18 22:12:07 +01:00 --- error: Missing i18n entry resource.aleph_id for language cs_CZ
2008-12-18 22:12:07 +01:00 --- error: Missing i18n entry resource.ISSN for language cs_CZ
2008-12-18 22:12:07 +01:00 --- error: Missing i18n entry resource.metadata for language cs_CZ
2008-12-18 22:12:07 +01:00 --- error: Missing i18n entry resource.catalogued for language cs_CZ
2008-12-18 22:12:07 +01:00 --- error: Missing i18n entry resource.creative_commons for language cs_CZ
2008-12-18 22:12:07 +01:00 --- error: Missing i18n entry resource.tech_problems for language cs_CZ
2008-12-18 22:12:07 +01:00 --- error: Missing i18n entry resource.comments for language cs_CZ
2008-12-18 22:13:17 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 22:13:17 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 22:13:17 +01:00 --- debug: Profiler Library initialized
2008-12-18 22:13:17 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-18 22:13:17 +01:00 --- debug: Database Library initialized
2008-12-18 22:13:21 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 22:13:21 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 22:13:21 +01:00 --- debug: Profiler Library initialized
2008-12-18 22:13:21 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-18 22:13:21 +01:00 --- debug: Database Library initialized
2008-12-18 22:14:38 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 22:14:38 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 22:14:38 +01:00 --- debug: Profiler Library initialized
2008-12-18 22:14:38 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-18 22:14:38 +01:00 --- debug: Database Library initialized
2008-12-18 22:16:23 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 22:16:23 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 22:16:23 +01:00 --- debug: Profiler Library initialized
2008-12-18 22:16:23 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-18 22:16:23 +01:00 --- debug: Database Library initialized
2008-12-18 22:16:23 +01:00 --- error: Missing i18n entry resource.id for language cs_CZ
2008-12-18 22:16:23 +01:00 --- error: Missing i18n entry resource.curator_id for language cs_CZ
2008-12-18 22:16:23 +01:00 --- error: Missing i18n entry resource.contact_id for language cs_CZ
2008-12-18 22:16:23 +01:00 --- error: Missing i18n entry resource.publisher_id for language cs_CZ
2008-12-18 22:16:23 +01:00 --- error: Missing i18n entry resource.contract_id for language cs_CZ
2008-12-18 22:16:23 +01:00 --- error: Missing i18n entry resource.conspectus_id for language cs_CZ
2008-12-18 22:16:23 +01:00 --- error: Missing i18n entry resource.crawl_freq_id for language cs_CZ
2008-12-18 22:16:23 +01:00 --- error: Missing i18n entry resource.resource_status_id for language cs_CZ
2008-12-18 22:16:23 +01:00 --- error: Missing i18n entry resource.suggested_by_id for language cs_CZ
2008-12-18 22:16:23 +01:00 --- error: Missing i18n entry resource.title for language cs_CZ
2008-12-18 22:16:23 +01:00 --- error: Missing i18n entry resource.url for language cs_CZ
2008-12-18 22:16:23 +01:00 --- error: Missing i18n entry resource.rating_result for language cs_CZ
2008-12-18 22:16:23 +01:00 --- error: Missing i18n entry resource.date for language cs_CZ
2008-12-18 22:16:23 +01:00 --- error: Missing i18n entry resource.aleph_id for language cs_CZ
2008-12-18 22:16:23 +01:00 --- error: Missing i18n entry resource.ISSN for language cs_CZ
2008-12-18 22:16:23 +01:00 --- error: Missing i18n entry resource.metadata for language cs_CZ
2008-12-18 22:16:23 +01:00 --- error: Missing i18n entry resource.catalogued for language cs_CZ
2008-12-18 22:16:23 +01:00 --- error: Missing i18n entry resource.creative_commons for language cs_CZ
2008-12-18 22:16:23 +01:00 --- error: Missing i18n entry resource.tech_problems for language cs_CZ
2008-12-18 22:16:23 +01:00 --- error: Missing i18n entry resource.comments for language cs_CZ
2008-12-18 22:17:04 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 22:17:04 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 22:17:04 +01:00 --- debug: Profiler Library initialized
2008-12-18 22:17:04 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-18 22:17:04 +01:00 --- debug: Database Library initialized
2008-12-18 22:17:04 +01:00 --- error: Missing i18n entry resource.id for language cs_CZ
2008-12-18 22:17:04 +01:00 --- error: Missing i18n entry resource.curator_id for language cs_CZ
2008-12-18 22:17:04 +01:00 --- error: Missing i18n entry resource.contact_id for language cs_CZ
2008-12-18 22:17:04 +01:00 --- error: Missing i18n entry resource.publisher_id for language cs_CZ
2008-12-18 22:17:04 +01:00 --- error: Missing i18n entry resource.contract_id for language cs_CZ
2008-12-18 22:17:04 +01:00 --- error: Missing i18n entry resource.conspectus_id for language cs_CZ
2008-12-18 22:17:04 +01:00 --- error: Missing i18n entry resource.crawl_freq_id for language cs_CZ
2008-12-18 22:17:04 +01:00 --- error: Missing i18n entry resource.resource_status_id for language cs_CZ
2008-12-18 22:17:04 +01:00 --- error: Missing i18n entry resource.suggested_by_id for language cs_CZ
2008-12-18 22:17:04 +01:00 --- error: Missing i18n entry resource.title for language cs_CZ
2008-12-18 22:17:04 +01:00 --- error: Missing i18n entry resource.url for language cs_CZ
2008-12-18 22:17:04 +01:00 --- error: Missing i18n entry resource.rating_result for language cs_CZ
2008-12-18 22:17:04 +01:00 --- error: Missing i18n entry resource.date for language cs_CZ
2008-12-18 22:17:04 +01:00 --- error: Missing i18n entry resource.aleph_id for language cs_CZ
2008-12-18 22:17:04 +01:00 --- error: Missing i18n entry resource.ISSN for language cs_CZ
2008-12-18 22:17:04 +01:00 --- error: Missing i18n entry resource.metadata for language cs_CZ
2008-12-18 22:17:04 +01:00 --- error: Missing i18n entry resource.catalogued for language cs_CZ
2008-12-18 22:17:04 +01:00 --- error: Missing i18n entry resource.creative_commons for language cs_CZ
2008-12-18 22:17:04 +01:00 --- error: Missing i18n entry resource.tech_problems for language cs_CZ
2008-12-18 22:17:04 +01:00 --- error: Missing i18n entry resource.comments for language cs_CZ
2008-12-18 22:17:21 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 22:17:21 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 22:17:21 +01:00 --- debug: Profiler Library initialized
2008-12-18 22:17:21 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-18 22:17:21 +01:00 --- debug: Database Library initialized
2008-12-18 22:17:21 +01:00 --- error: Missing i18n entry resource.id for language cs_CZ
2008-12-18 22:17:21 +01:00 --- error: Missing i18n entry resource.curator_id for language cs_CZ
2008-12-18 22:17:21 +01:00 --- error: Missing i18n entry resource.contact_id for language cs_CZ
2008-12-18 22:17:21 +01:00 --- error: Missing i18n entry resource.publisher_id for language cs_CZ
2008-12-18 22:17:21 +01:00 --- error: Missing i18n entry resource.contract_id for language cs_CZ
2008-12-18 22:17:21 +01:00 --- error: Missing i18n entry resource.conspectus_id for language cs_CZ
2008-12-18 22:17:21 +01:00 --- error: Missing i18n entry resource.crawl_freq_id for language cs_CZ
2008-12-18 22:17:21 +01:00 --- error: Missing i18n entry resource.resource_status_id for language cs_CZ
2008-12-18 22:17:21 +01:00 --- error: Missing i18n entry resource.suggested_by_id for language cs_CZ
2008-12-18 22:17:21 +01:00 --- error: Missing i18n entry resource.title for language cs_CZ
2008-12-18 22:17:21 +01:00 --- error: Missing i18n entry resource.url for language cs_CZ
2008-12-18 22:17:21 +01:00 --- error: Missing i18n entry resource.rating_result for language cs_CZ
2008-12-18 22:17:21 +01:00 --- error: Missing i18n entry resource.date for language cs_CZ
2008-12-18 22:17:21 +01:00 --- error: Missing i18n entry resource.aleph_id for language cs_CZ
2008-12-18 22:17:21 +01:00 --- error: Missing i18n entry resource.ISSN for language cs_CZ
2008-12-18 22:17:21 +01:00 --- error: Missing i18n entry resource.metadata for language cs_CZ
2008-12-18 22:17:21 +01:00 --- error: Missing i18n entry resource.catalogued for language cs_CZ
2008-12-18 22:17:21 +01:00 --- error: Missing i18n entry resource.creative_commons for language cs_CZ
2008-12-18 22:17:21 +01:00 --- error: Missing i18n entry resource.tech_problems for language cs_CZ
2008-12-18 22:17:21 +01:00 --- error: Missing i18n entry resource.comments for language cs_CZ
2008-12-18 22:19:31 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 22:19:31 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 22:19:31 +01:00 --- debug: Profiler Library initialized
2008-12-18 22:19:31 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-18 22:19:31 +01:00 --- debug: Database Library initialized
2008-12-18 22:19:31 +01:00 --- error: Missing i18n entry resource.id for language cs_CZ
2008-12-18 22:19:31 +01:00 --- error: Missing i18n entry resource.curator_id for language cs_CZ
2008-12-18 22:19:31 +01:00 --- error: Missing i18n entry resource.contact_id for language cs_CZ
2008-12-18 22:19:31 +01:00 --- error: Missing i18n entry resource.publisher_id for language cs_CZ
2008-12-18 22:19:31 +01:00 --- error: Missing i18n entry resource.contract_id for language cs_CZ
2008-12-18 22:19:31 +01:00 --- error: Missing i18n entry resource.conspectus_id for language cs_CZ
2008-12-18 22:19:31 +01:00 --- error: Missing i18n entry resource.crawl_freq_id for language cs_CZ
2008-12-18 22:19:31 +01:00 --- error: Missing i18n entry resource.resource_status_id for language cs_CZ
2008-12-18 22:19:31 +01:00 --- error: Missing i18n entry resource.suggested_by_id for language cs_CZ
2008-12-18 22:19:31 +01:00 --- error: Missing i18n entry resource.title for language cs_CZ
2008-12-18 22:19:31 +01:00 --- error: Missing i18n entry resource.url for language cs_CZ
2008-12-18 22:19:31 +01:00 --- error: Missing i18n entry resource.rating_result for language cs_CZ
2008-12-18 22:19:31 +01:00 --- error: Missing i18n entry resource.date for language cs_CZ
2008-12-18 22:19:31 +01:00 --- error: Missing i18n entry resource.aleph_id for language cs_CZ
2008-12-18 22:19:31 +01:00 --- error: Missing i18n entry resource.ISSN for language cs_CZ
2008-12-18 22:19:31 +01:00 --- error: Missing i18n entry resource.metadata for language cs_CZ
2008-12-18 22:19:31 +01:00 --- error: Missing i18n entry resource.catalogued for language cs_CZ
2008-12-18 22:19:31 +01:00 --- error: Missing i18n entry resource.creative_commons for language cs_CZ
2008-12-18 22:19:31 +01:00 --- error: Missing i18n entry resource.tech_problems for language cs_CZ
2008-12-18 22:19:31 +01:00 --- error: Missing i18n entry resource.comments for language cs_CZ
2008-12-18 22:19:39 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 22:19:39 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 22:19:39 +01:00 --- debug: Profiler Library initialized
2008-12-18 22:19:39 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-18 22:19:39 +01:00 --- debug: Database Library initialized
2008-12-18 22:26:02 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 22:26:02 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 22:26:02 +01:00 --- debug: Profiler Library initialized
2008-12-18 22:26:02 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-18 22:26:02 +01:00 --- debug: Database Library initialized
2008-12-18 22:26:49 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 22:26:49 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 22:26:49 +01:00 --- debug: Profiler Library initialized
2008-12-18 22:26:49 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-18 22:26:49 +01:00 --- debug: Database Library initialized
2008-12-18 22:27:33 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 22:27:33 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 22:27:33 +01:00 --- debug: Profiler Library initialized
2008-12-18 22:27:33 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-18 22:27:33 +01:00 --- debug: Database Library initialized
2008-12-18 22:27:49 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 22:27:49 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 22:27:49 +01:00 --- debug: Profiler Library initialized
2008-12-18 22:27:49 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-18 22:27:49 +01:00 --- debug: Database Library initialized
2008-12-18 22:28:42 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 22:28:42 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 22:28:42 +01:00 --- debug: Profiler Library initialized
2008-12-18 22:28:42 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-18 22:28:42 +01:00 --- debug: Database Library initialized
2008-12-18 22:29:30 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 22:29:30 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 22:29:30 +01:00 --- debug: Profiler Library initialized
2008-12-18 22:29:30 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-18 22:29:30 +01:00 --- debug: Database Library initialized
2008-12-18 22:33:35 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 22:33:35 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 22:33:35 +01:00 --- debug: Profiler Library initialized
2008-12-18 22:33:35 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-18 22:33:35 +01:00 --- debug: Database Library initialized
2008-12-18 22:34:33 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 22:34:33 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 22:34:33 +01:00 --- debug: Profiler Library initialized
2008-12-18 22:34:33 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-18 22:34:33 +01:00 --- debug: Database Library initialized
2008-12-18 22:35:30 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 22:35:30 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 22:35:30 +01:00 --- debug: Profiler Library initialized
2008-12-18 22:35:30 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-18 22:35:30 +01:00 --- debug: Database Library initialized
2008-12-18 22:35:31 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 22:35:31 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 22:35:31 +01:00 --- debug: Profiler Library initialized
2008-12-18 22:35:31 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-18 22:35:31 +01:00 --- debug: Database Library initialized
2008-12-18 22:38:08 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 22:38:08 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 22:38:08 +01:00 --- debug: Profiler Library initialized
2008-12-18 22:38:08 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-18 22:38:08 +01:00 --- debug: Database Library initialized
2008-12-18 22:38:09 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 22:38:09 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 22:38:09 +01:00 --- debug: Profiler Library initialized
2008-12-18 22:38:09 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-18 22:38:09 +01:00 --- debug: Database Library initialized
2008-12-18 22:38:20 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 22:38:20 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 22:38:20 +01:00 --- debug: Profiler Library initialized
2008-12-18 22:38:20 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-18 22:38:20 +01:00 --- debug: Database Library initialized
2008-12-18 22:39:09 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 22:39:09 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 22:39:09 +01:00 --- debug: Profiler Library initialized
2008-12-18 22:39:09 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-18 22:39:09 +01:00 --- debug: Database Library initialized
2008-12-18 22:39:27 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 22:39:27 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 22:39:27 +01:00 --- debug: Profiler Library initialized
2008-12-18 22:39:27 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-18 22:39:27 +01:00 --- debug: Database Library initialized
2008-12-18 22:40:07 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 22:40:07 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 22:40:07 +01:00 --- debug: Profiler Library initialized
2008-12-18 22:40:07 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-18 22:40:07 +01:00 --- debug: Database Library initialized
2008-12-18 22:40:08 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 22:40:08 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 22:40:08 +01:00 --- debug: Profiler Library initialized
2008-12-18 22:40:08 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-18 22:40:08 +01:00 --- debug: Database Library initialized
2008-12-18 22:40:35 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 22:40:35 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 22:40:35 +01:00 --- debug: Profiler Library initialized
2008-12-18 22:40:35 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-18 22:40:35 +01:00 --- debug: Database Library initialized
2008-12-18 22:40:50 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 22:40:50 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 22:40:50 +01:00 --- debug: Profiler Library initialized
2008-12-18 22:40:50 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-18 22:40:50 +01:00 --- debug: Database Library initialized
2008-12-18 22:43:35 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 22:43:35 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 22:43:35 +01:00 --- debug: Profiler Library initialized
2008-12-18 22:43:35 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-18 22:43:35 +01:00 --- debug: Database Library initialized
2008-12-18 22:43:43 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 22:43:43 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 22:43:43 +01:00 --- debug: Profiler Library initialized
2008-12-18 22:43:43 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-18 22:43:43 +01:00 --- debug: Database Library initialized
2008-12-18 22:43:59 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 22:43:59 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 22:43:59 +01:00 --- debug: Profiler Library initialized
2008-12-18 22:43:59 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-18 22:43:59 +01:00 --- debug: Database Library initialized
2008-12-18 22:44:03 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 22:44:03 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 22:44:03 +01:00 --- debug: Profiler Library initialized
2008-12-18 22:44:04 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-18 22:44:04 +01:00 --- debug: Database Library initialized
2008-12-18 22:45:02 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 22:45:02 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 22:45:02 +01:00 --- debug: Profiler Library initialized
2008-12-18 22:45:02 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-18 22:45:02 +01:00 --- debug: Database Library initialized
2008-12-18 22:45:08 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 22:45:08 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 22:45:08 +01:00 --- debug: Profiler Library initialized
2008-12-18 22:45:08 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-18 22:45:08 +01:00 --- debug: Database Library initialized
2008-12-18 22:49:25 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 22:49:25 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 22:49:25 +01:00 --- debug: Profiler Library initialized
2008-12-18 22:49:25 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-18 22:49:25 +01:00 --- debug: Database Library initialized
2008-12-18 22:49:27 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 22:49:27 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 22:49:27 +01:00 --- debug: Profiler Library initialized
2008-12-18 22:49:28 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 22:49:28 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 22:49:28 +01:00 --- debug: Profiler Library initialized
2008-12-18 22:49:28 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 22:49:28 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 22:49:28 +01:00 --- debug: Profiler Library initialized
2008-12-18 22:49:29 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 22:49:29 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 22:49:29 +01:00 --- debug: Profiler Library initialized
2008-12-18 22:49:30 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 22:49:30 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 22:49:30 +01:00 --- debug: Profiler Library initialized
2008-12-18 22:49:31 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 22:49:31 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 22:49:31 +01:00 --- debug: Profiler Library initialized
2008-12-18 22:49:33 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 22:49:33 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 22:49:33 +01:00 --- debug: Profiler Library initialized
2008-12-18 22:49:35 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 22:49:35 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 22:49:35 +01:00 --- debug: Profiler Library initialized
2008-12-18 22:49:35 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-18 22:49:35 +01:00 --- debug: Database Library initialized
2008-12-18 22:52:33 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 22:52:33 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 22:52:33 +01:00 --- debug: Profiler Library initialized
2008-12-18 22:52:33 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-18 22:52:33 +01:00 --- debug: Database Library initialized
2008-12-18 22:58:31 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 22:58:31 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 22:58:31 +01:00 --- debug: Profiler Library initialized
2008-12-18 22:58:31 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-18 22:58:31 +01:00 --- debug: Database Library initialized
2008-12-18 22:58:58 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 22:58:58 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 22:58:58 +01:00 --- debug: Profiler Library initialized
2008-12-18 22:58:58 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-18 22:58:58 +01:00 --- debug: Database Library initialized
2008-12-18 22:58:58 +01:00 --- error: Missing i18n entry resource.id for language cs_CZ
2008-12-18 22:58:58 +01:00 --- error: Missing i18n entry resource.curator_id for language cs_CZ
2008-12-18 22:58:58 +01:00 --- error: Missing i18n entry resource.contact_id for language cs_CZ
2008-12-18 22:58:58 +01:00 --- error: Missing i18n entry resource.publisher_id for language cs_CZ
2008-12-18 22:58:58 +01:00 --- error: Missing i18n entry resource.contract_id for language cs_CZ
2008-12-18 22:58:58 +01:00 --- error: Missing i18n entry resource.conspectus_id for language cs_CZ
2008-12-18 22:58:58 +01:00 --- error: Missing i18n entry resource.crawl_freq_id for language cs_CZ
2008-12-18 22:58:58 +01:00 --- error: Missing i18n entry resource.resource_status_id for language cs_CZ
2008-12-18 22:58:58 +01:00 --- error: Missing i18n entry resource.suggested_by_id for language cs_CZ
2008-12-18 22:58:58 +01:00 --- error: Missing i18n entry resource.title for language cs_CZ
2008-12-18 22:58:58 +01:00 --- error: Missing i18n entry resource.url for language cs_CZ
2008-12-18 22:58:58 +01:00 --- error: Missing i18n entry resource.rating_result for language cs_CZ
2008-12-18 22:58:58 +01:00 --- error: Missing i18n entry resource.date for language cs_CZ
2008-12-18 22:58:58 +01:00 --- error: Missing i18n entry resource.aleph_id for language cs_CZ
2008-12-18 22:58:58 +01:00 --- error: Missing i18n entry resource.ISSN for language cs_CZ
2008-12-18 22:58:58 +01:00 --- error: Missing i18n entry resource.metadata for language cs_CZ
2008-12-18 22:58:58 +01:00 --- error: Missing i18n entry resource.catalogued for language cs_CZ
2008-12-18 22:58:58 +01:00 --- error: Missing i18n entry resource.creative_commons for language cs_CZ
2008-12-18 22:58:58 +01:00 --- error: Missing i18n entry resource.tech_problems for language cs_CZ
2008-12-18 22:58:58 +01:00 --- error: Missing i18n entry resource.comments for language cs_CZ
2008-12-18 23:01:28 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 23:01:28 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 23:01:28 +01:00 --- debug: Profiler Library initialized
2008-12-18 23:01:28 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-18 23:01:28 +01:00 --- debug: Database Library initialized
2008-12-18 23:01:45 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 23:01:45 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 23:01:45 +01:00 --- debug: Profiler Library initialized
2008-12-18 23:01:45 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-18 23:01:45 +01:00 --- debug: Database Library initialized
2008-12-18 23:04:38 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 23:04:38 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 23:04:38 +01:00 --- debug: Profiler Library initialized
2008-12-18 23:04:38 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-18 23:04:38 +01:00 --- debug: Database Library initialized
2008-12-18 23:04:39 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 23:04:39 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 23:04:39 +01:00 --- debug: Profiler Library initialized
2008-12-18 23:04:39 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-18 23:04:39 +01:00 --- debug: Database Library initialized
2008-12-18 23:04:46 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 23:04:46 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 23:04:46 +01:00 --- debug: Profiler Library initialized
2008-12-18 23:04:46 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-18 23:04:46 +01:00 --- debug: Database Library initialized
2008-12-18 23:05:18 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 23:05:18 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 23:05:18 +01:00 --- debug: Profiler Library initialized
2008-12-18 23:05:18 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-18 23:05:18 +01:00 --- debug: Database Library initialized
2008-12-18 23:08:01 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 23:08:01 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 23:08:01 +01:00 --- debug: Profiler Library initialized
2008-12-18 23:08:01 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-18 23:08:01 +01:00 --- debug: Database Library initialized
2008-12-18 23:12:33 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 23:12:33 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 23:12:33 +01:00 --- debug: Profiler Library initialized
2008-12-18 23:12:33 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-18 23:12:33 +01:00 --- debug: Database Library initialized
2008-12-18 23:13:27 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 23:13:27 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 23:13:27 +01:00 --- debug: Profiler Library initialized
2008-12-18 23:13:27 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-18 23:13:27 +01:00 --- debug: Database Library initialized
2008-12-18 23:14:26 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 23:14:26 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 23:14:26 +01:00 --- debug: Profiler Library initialized
2008-12-18 23:14:26 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-18 23:14:26 +01:00 --- debug: Database Library initialized
2008-12-18 23:17:18 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 23:17:18 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 23:17:18 +01:00 --- debug: Profiler Library initialized
2008-12-18 23:17:18 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-18 23:17:18 +01:00 --- debug: Database Library initialized
2008-12-18 23:17:29 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 23:17:29 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 23:17:29 +01:00 --- debug: Profiler Library initialized
2008-12-18 23:17:29 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-18 23:17:29 +01:00 --- debug: Database Library initialized
2008-12-18 23:17:52 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 23:17:52 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 23:17:52 +01:00 --- debug: Profiler Library initialized
2008-12-18 23:17:52 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-18 23:17:52 +01:00 --- debug: Database Library initialized
2008-12-18 23:18:35 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 23:18:35 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 23:18:35 +01:00 --- debug: Profiler Library initialized
2008-12-18 23:18:35 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-18 23:18:35 +01:00 --- debug: Database Library initialized
2008-12-18 23:19:02 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 23:19:02 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 23:19:02 +01:00 --- debug: Profiler Library initialized
2008-12-18 23:19:02 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-18 23:19:02 +01:00 --- debug: Database Library initialized
2008-12-18 23:23:49 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 23:23:49 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 23:23:49 +01:00 --- debug: Profiler Library initialized
2008-12-18 23:23:49 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-18 23:23:49 +01:00 --- debug: Database Library initialized
2008-12-18 23:24:03 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 23:24:03 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 23:24:03 +01:00 --- debug: Profiler Library initialized
2008-12-18 23:24:03 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-18 23:24:03 +01:00 --- debug: Database Library initialized
2008-12-18 23:24:23 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 23:24:23 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 23:24:23 +01:00 --- debug: Profiler Library initialized
2008-12-18 23:24:23 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-18 23:24:23 +01:00 --- debug: Database Library initialized
2008-12-18 23:24:42 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 23:24:42 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 23:24:42 +01:00 --- debug: Profiler Library initialized
2008-12-18 23:24:42 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-18 23:24:42 +01:00 --- debug: Database Library initialized
2008-12-18 23:24:50 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 23:24:50 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 23:24:50 +01:00 --- debug: Profiler Library initialized
2008-12-18 23:24:51 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-18 23:24:51 +01:00 --- debug: Database Library initialized
2008-12-18 23:26:28 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 23:26:28 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 23:26:28 +01:00 --- debug: Profiler Library initialized
2008-12-18 23:26:28 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-18 23:26:28 +01:00 --- debug: Database Library initialized
2008-12-18 23:26:32 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 23:26:32 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 23:26:32 +01:00 --- debug: Profiler Library initialized
2008-12-18 23:26:32 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-18 23:26:32 +01:00 --- debug: Database Library initialized
2008-12-18 23:26:41 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 23:26:41 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 23:26:41 +01:00 --- debug: Profiler Library initialized
2008-12-18 23:26:41 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-18 23:26:41 +01:00 --- debug: Database Library initialized
2008-12-18 23:32:21 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 23:32:21 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 23:32:21 +01:00 --- debug: Profiler Library initialized
2008-12-18 23:32:21 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-18 23:32:21 +01:00 --- debug: Database Library initialized
2008-12-18 23:33:29 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 23:33:29 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 23:33:29 +01:00 --- debug: Profiler Library initialized
2008-12-18 23:33:29 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-18 23:33:29 +01:00 --- debug: Database Library initialized
2008-12-18 23:40:17 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 23:40:17 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 23:40:17 +01:00 --- debug: Profiler Library initialized
2008-12-18 23:40:17 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-18 23:40:17 +01:00 --- debug: Database Library initialized
2008-12-18 23:40:45 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 23:40:45 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 23:40:45 +01:00 --- debug: Profiler Library initialized
2008-12-18 23:40:45 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-18 23:40:45 +01:00 --- debug: Database Library initialized
2008-12-18 23:42:30 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-18 23:42:30 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-18 23:42:30 +01:00 --- debug: Profiler Library initialized
2008-12-18 23:42:30 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-18 23:42:30 +01:00 --- debug: Database Library initialized
