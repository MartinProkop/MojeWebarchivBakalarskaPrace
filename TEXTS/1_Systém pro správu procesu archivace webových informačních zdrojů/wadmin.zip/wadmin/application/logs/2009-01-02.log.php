<?php defined('SYSPATH') or die('No direct script access.'); ?>

2009-01-02 13:22:58 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2009-01-02 13:22:58 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2009-01-02 13:22:58 +01:00 --- debug: Profiler Library initialized
2009-01-02 13:22:59 +01:00 --- debug: MySQL Database Driver Initialized
2009-01-02 13:22:59 +01:00 --- debug: Database Library initialized
2009-01-02 15:51:19 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2009-01-02 15:51:19 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2009-01-02 15:51:19 +01:00 --- debug: Profiler Library initialized
2009-01-02 15:51:19 +01:00 --- debug: MySQL Database Driver Initialized
2009-01-02 15:51:19 +01:00 --- debug: Database Library initialized
2009-01-02 15:51:52 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2009-01-02 15:51:52 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2009-01-02 15:51:52 +01:00 --- debug: Profiler Library initialized
2009-01-02 15:51:52 +01:00 --- debug: MySQL Database Driver Initialized
2009-01-02 15:51:52 +01:00 --- debug: Database Library initialized
2009-01-02 15:51:53 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2009-01-02 15:51:53 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2009-01-02 15:51:53 +01:00 --- debug: Profiler Library initialized
2009-01-02 15:51:53 +01:00 --- debug: MySQL Database Driver Initialized
2009-01-02 15:51:53 +01:00 --- debug: Database Library initialized
2009-01-02 15:51:53 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2009-01-02 15:51:53 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2009-01-02 15:51:53 +01:00 --- debug: Profiler Library initialized
2009-01-02 15:51:53 +01:00 --- debug: MySQL Database Driver Initialized
2009-01-02 15:51:53 +01:00 --- debug: Database Library initialized
2009-01-02 15:52:32 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2009-01-02 15:52:32 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2009-01-02 15:52:32 +01:00 --- debug: Profiler Library initialized
2009-01-02 15:52:32 +01:00 --- debug: MySQL Database Driver Initialized
2009-01-02 15:52:32 +01:00 --- debug: Database Library initialized
2009-01-02 15:53:56 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2009-01-02 15:53:56 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2009-01-02 15:53:56 +01:00 --- debug: Profiler Library initialized
2009-01-02 15:53:56 +01:00 --- debug: MySQL Database Driver Initialized
2009-01-02 15:53:56 +01:00 --- debug: Database Library initialized
2009-01-02 15:54:24 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2009-01-02 15:54:24 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2009-01-02 15:54:24 +01:00 --- debug: Profiler Library initialized
2009-01-02 15:54:24 +01:00 --- debug: MySQL Database Driver Initialized
2009-01-02 15:54:24 +01:00 --- debug: Database Library initialized
2009-01-02 15:59:57 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2009-01-02 15:59:57 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2009-01-02 15:59:57 +01:00 --- debug: Profiler Library initialized
2009-01-02 15:59:57 +01:00 --- debug: MySQL Database Driver Initialized
2009-01-02 15:59:57 +01:00 --- debug: Database Library initialized
2009-01-02 16:40:35 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2009-01-02 16:40:35 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2009-01-02 16:40:35 +01:00 --- debug: Profiler Library initialized
2009-01-02 16:40:37 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2009-01-02 16:40:37 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2009-01-02 16:40:37 +01:00 --- debug: Profiler Library initialized
2009-01-02 16:40:38 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2009-01-02 16:40:38 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2009-01-02 16:40:38 +01:00 --- debug: Profiler Library initialized
2009-01-02 16:40:40 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2009-01-02 16:40:40 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2009-01-02 16:40:40 +01:00 --- debug: Profiler Library initialized
2009-01-02 17:29:27 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2009-01-02 17:29:27 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2009-01-02 17:29:27 +01:00 --- debug: Profiler Library initialized
2009-01-02 17:29:27 +01:00 --- debug: MySQL Database Driver Initialized
2009-01-02 17:29:27 +01:00 --- debug: Database Library initialized
2009-01-02 20:02:10 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2009-01-02 20:02:10 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2009-01-02 20:02:10 +01:00 --- debug: Profiler Library initialized
2009-01-02 20:02:10 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2009-01-02 20:02:10 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2009-01-02 20:02:10 +01:00 --- debug: Profiler Library initialized
2009-01-02 20:02:10 +01:00 --- debug: MySQL Database Driver Initialized
2009-01-02 20:02:10 +01:00 --- debug: Database Library initialized
2009-01-02 21:30:57 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2009-01-02 21:30:57 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2009-01-02 21:30:57 +01:00 --- debug: Profiler Library initialized
2009-01-02 21:30:58 +01:00 --- debug: MySQL Database Driver Initialized
2009-01-02 21:30:58 +01:00 --- debug: Database Library initialized
2009-01-02 21:30:58 +01:00 --- error: Missing i18n entry tables.Contracts for language cs_CZ
2009-01-02 21:30:58 +01:00 --- error: Missing i18n entry tables.Contracts for language cs_CZ
2009-01-02 21:30:58 +01:00 --- error: Missing i18n entry tables.addendum for language cs_CZ
2009-01-02 21:30:58 +01:00 --- error: Missing i18n entry tables.cc for language cs_CZ
2009-01-02 21:31:26 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2009-01-02 21:31:26 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2009-01-02 21:31:26 +01:00 --- debug: Profiler Library initialized
2009-01-02 21:31:26 +01:00 --- debug: MySQL Database Driver Initialized
2009-01-02 21:31:26 +01:00 --- debug: Database Library initialized
2009-01-02 21:31:31 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2009-01-02 21:31:31 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2009-01-02 21:31:31 +01:00 --- debug: Profiler Library initialized
2009-01-02 21:31:31 +01:00 --- debug: MySQL Database Driver Initialized
2009-01-02 21:31:31 +01:00 --- debug: Database Library initialized
2009-01-02 21:31:31 +01:00 --- error: Missing i18n entry tables.position for language cs_CZ
2009-01-02 21:31:54 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2009-01-02 21:31:54 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2009-01-02 21:31:54 +01:00 --- debug: Profiler Library initialized
2009-01-02 21:31:55 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2009-01-02 21:31:55 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2009-01-02 21:31:55 +01:00 --- debug: Profiler Library initialized
2009-01-02 21:31:55 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2009-01-02 21:31:55 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2009-01-02 21:31:55 +01:00 --- debug: Profiler Library initialized
2009-01-02 21:31:55 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2009-01-02 21:31:55 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2009-01-02 21:31:55 +01:00 --- debug: Profiler Library initialized
2009-01-02 21:31:55 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2009-01-02 21:31:55 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2009-01-02 21:31:55 +01:00 --- debug: Profiler Library initialized
2009-01-02 21:31:55 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2009-01-02 21:31:55 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2009-01-02 21:31:55 +01:00 --- debug: Profiler Library initialized
2009-01-02 21:31:55 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2009-01-02 21:31:55 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2009-01-02 21:31:55 +01:00 --- debug: Profiler Library initialized
2009-01-02 21:31:55 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2009-01-02 21:31:55 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2009-01-02 21:31:55 +01:00 --- debug: Profiler Library initialized
2009-01-02 21:32:26 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2009-01-02 21:32:26 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2009-01-02 21:32:26 +01:00 --- debug: Profiler Library initialized
2009-01-02 21:32:28 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2009-01-02 21:32:28 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2009-01-02 21:32:28 +01:00 --- debug: Profiler Library initialized
2009-01-02 21:32:29 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2009-01-02 21:32:29 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2009-01-02 21:32:29 +01:00 --- debug: Profiler Library initialized
2009-01-02 21:32:30 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2009-01-02 21:32:30 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2009-01-02 21:32:30 +01:00 --- debug: Profiler Library initialized
2009-01-02 21:32:31 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2009-01-02 21:32:31 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2009-01-02 21:32:31 +01:00 --- debug: Profiler Library initialized
2009-01-02 21:34:07 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2009-01-02 21:34:07 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2009-01-02 21:34:07 +01:00 --- debug: Profiler Library initialized
2009-01-02 21:34:08 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2009-01-02 21:34:08 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2009-01-02 21:34:08 +01:00 --- debug: Profiler Library initialized
2009-01-02 21:36:26 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2009-01-02 21:36:26 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2009-01-02 21:36:26 +01:00 --- debug: Profiler Library initialized
2009-01-02 21:36:26 +01:00 --- debug: MySQL Database Driver Initialized
2009-01-02 21:36:26 +01:00 --- debug: Database Library initialized
2009-01-02 21:36:44 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2009-01-02 21:36:44 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2009-01-02 21:36:44 +01:00 --- debug: Profiler Library initialized
2009-01-02 21:36:44 +01:00 --- debug: MySQL Database Driver Initialized
2009-01-02 21:36:44 +01:00 --- debug: Database Library initialized
2009-01-02 23:17:35 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2009-01-02 23:17:35 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2009-01-02 23:17:35 +01:00 --- debug: Profiler Library initialized
2009-01-02 23:17:35 +01:00 --- debug: MySQL Database Driver Initialized
2009-01-02 23:17:35 +01:00 --- debug: Database Library initialized
2009-01-02 23:19:41 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2009-01-02 23:19:41 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2009-01-02 23:19:41 +01:00 --- debug: Profiler Library initialized
2009-01-02 23:19:41 +01:00 --- debug: MySQL Database Driver Initialized
2009-01-02 23:19:41 +01:00 --- debug: Database Library initialized
2009-01-02 23:20:00 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2009-01-02 23:20:00 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2009-01-02 23:20:00 +01:00 --- debug: Profiler Library initialized
2009-01-02 23:20:00 +01:00 --- debug: MySQL Database Driver Initialized
2009-01-02 23:20:00 +01:00 --- debug: Database Library initialized
2009-01-02 23:20:22 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2009-01-02 23:20:22 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2009-01-02 23:20:22 +01:00 --- debug: Profiler Library initialized
2009-01-02 23:20:22 +01:00 --- debug: MySQL Database Driver Initialized
2009-01-02 23:20:22 +01:00 --- debug: Database Library initialized
2009-01-02 23:22:40 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2009-01-02 23:22:40 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2009-01-02 23:22:40 +01:00 --- debug: Profiler Library initialized
2009-01-02 23:22:40 +01:00 --- debug: MySQL Database Driver Initialized
2009-01-02 23:22:40 +01:00 --- debug: Database Library initialized
2009-01-02 23:28:50 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2009-01-02 23:28:50 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2009-01-02 23:28:50 +01:00 --- debug: Profiler Library initialized
2009-01-02 23:40:23 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2009-01-02 23:40:23 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2009-01-02 23:40:23 +01:00 --- debug: Profiler Library initialized
2009-01-02 23:40:23 +01:00 --- debug: MySQL Database Driver Initialized
2009-01-02 23:40:23 +01:00 --- debug: Database Library initialized
2009-01-02 23:46:21 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2009-01-02 23:46:21 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2009-01-02 23:46:21 +01:00 --- debug: Profiler Library initialized
2009-01-02 23:46:21 +01:00 --- debug: MySQL Database Driver Initialized
2009-01-02 23:46:21 +01:00 --- debug: Database Library initialized
2009-01-02 23:46:22 +01:00 --- debug: Pagination Library initialized
2009-01-02 23:48:10 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2009-01-02 23:48:10 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2009-01-02 23:48:10 +01:00 --- debug: Profiler Library initialized
2009-01-02 23:48:10 +01:00 --- debug: MySQL Database Driver Initialized
2009-01-02 23:48:10 +01:00 --- debug: Database Library initialized
2009-01-02 23:48:10 +01:00 --- debug: Pagination Library initialized
2009-01-02 23:49:46 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2009-01-02 23:49:46 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2009-01-02 23:49:46 +01:00 --- debug: Profiler Library initialized
2009-01-02 23:49:47 +01:00 --- debug: MySQL Database Driver Initialized
2009-01-02 23:49:47 +01:00 --- debug: Database Library initialized
2009-01-02 23:49:47 +01:00 --- debug: Pagination Library initialized
2009-01-02 23:51:43 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2009-01-02 23:51:43 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2009-01-02 23:51:43 +01:00 --- debug: Profiler Library initialized
2009-01-02 23:51:43 +01:00 --- debug: MySQL Database Driver Initialized
2009-01-02 23:51:43 +01:00 --- debug: Database Library initialized
2009-01-02 23:51:43 +01:00 --- debug: Pagination Library initialized
2009-01-02 23:52:11 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2009-01-02 23:52:11 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2009-01-02 23:52:11 +01:00 --- debug: Profiler Library initialized
2009-01-02 23:52:11 +01:00 --- debug: MySQL Database Driver Initialized
2009-01-02 23:52:11 +01:00 --- debug: Database Library initialized
2009-01-02 23:52:11 +01:00 --- debug: Pagination Library initialized
2009-01-02 23:52:41 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2009-01-02 23:52:41 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2009-01-02 23:52:41 +01:00 --- debug: Profiler Library initialized
2009-01-02 23:52:41 +01:00 --- debug: MySQL Database Driver Initialized
2009-01-02 23:52:41 +01:00 --- debug: Database Library initialized
2009-01-02 23:52:41 +01:00 --- debug: Pagination Library initialized
2009-01-02 23:52:42 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2009-01-02 23:52:42 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2009-01-02 23:52:42 +01:00 --- debug: Profiler Library initialized
2009-01-02 23:52:43 +01:00 --- debug: MySQL Database Driver Initialized
2009-01-02 23:52:43 +01:00 --- debug: Database Library initialized
2009-01-02 23:52:43 +01:00 --- debug: Pagination Library initialized
2009-01-02 23:52:57 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2009-01-02 23:52:57 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2009-01-02 23:52:57 +01:00 --- debug: Profiler Library initialized
2009-01-02 23:52:57 +01:00 --- debug: MySQL Database Driver Initialized
2009-01-02 23:52:57 +01:00 --- debug: Database Library initialized
2009-01-02 23:52:57 +01:00 --- debug: Pagination Library initialized
2009-01-02 23:53:09 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2009-01-02 23:53:09 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2009-01-02 23:53:09 +01:00 --- debug: Profiler Library initialized
2009-01-02 23:53:09 +01:00 --- debug: MySQL Database Driver Initialized
2009-01-02 23:53:09 +01:00 --- debug: Database Library initialized
2009-01-02 23:53:09 +01:00 --- debug: Pagination Library initialized
2009-01-02 23:53:13 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2009-01-02 23:53:14 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2009-01-02 23:53:14 +01:00 --- debug: Profiler Library initialized
2009-01-02 23:53:14 +01:00 --- debug: MySQL Database Driver Initialized
2009-01-02 23:53:14 +01:00 --- debug: Database Library initialized
2009-01-02 23:53:14 +01:00 --- debug: Pagination Library initialized
2009-01-02 23:53:20 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2009-01-02 23:53:20 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2009-01-02 23:53:20 +01:00 --- debug: Profiler Library initialized
2009-01-02 23:53:20 +01:00 --- debug: MySQL Database Driver Initialized
2009-01-02 23:53:20 +01:00 --- debug: Database Library initialized
2009-01-02 23:53:20 +01:00 --- debug: Pagination Library initialized
2009-01-02 23:53:21 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2009-01-02 23:53:21 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2009-01-02 23:53:21 +01:00 --- debug: Profiler Library initialized
2009-01-02 23:53:21 +01:00 --- debug: MySQL Database Driver Initialized
2009-01-02 23:53:21 +01:00 --- debug: Database Library initialized
2009-01-02 23:53:21 +01:00 --- debug: Pagination Library initialized
2009-01-02 23:53:23 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2009-01-02 23:53:23 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2009-01-02 23:53:23 +01:00 --- debug: Profiler Library initialized
2009-01-02 23:53:23 +01:00 --- debug: MySQL Database Driver Initialized
2009-01-02 23:53:23 +01:00 --- debug: Database Library initialized
2009-01-02 23:53:23 +01:00 --- debug: Pagination Library initialized
2009-01-02 23:59:19 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2009-01-02 23:59:19 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2009-01-02 23:59:19 +01:00 --- debug: Profiler Library initialized
2009-01-02 23:59:20 +01:00 --- debug: MySQL Database Driver Initialized
2009-01-02 23:59:20 +01:00 --- debug: Database Library initialized
2009-01-02 23:59:20 +01:00 --- debug: Pagination Library initialized
