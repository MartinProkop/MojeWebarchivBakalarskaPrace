<?php defined('SYSPATH') or die('No direct script access.'); ?>

2008-12-30 13:15:23 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-30 13:15:23 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-30 13:15:23 +01:00 --- debug: Profiler Library initialized
2008-12-30 13:15:23 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-30 13:15:23 +01:00 --- debug: Database Library initialized
2008-12-30 13:23:28 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-30 13:23:28 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-30 13:23:28 +01:00 --- debug: Profiler Library initialized
2008-12-30 13:23:28 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-30 13:23:28 +01:00 --- debug: Database Library initialized
2008-12-30 13:23:43 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-30 13:23:43 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-30 13:23:43 +01:00 --- debug: Profiler Library initialized
2008-12-30 13:23:44 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-30 13:23:44 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-30 13:23:44 +01:00 --- debug: Profiler Library initialized
2008-12-30 13:23:45 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-30 13:23:45 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-30 13:23:45 +01:00 --- debug: Profiler Library initialized
2008-12-30 13:23:46 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-30 13:23:46 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-30 13:23:46 +01:00 --- debug: Profiler Library initialized
2008-12-30 13:23:47 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-30 13:23:47 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-30 13:23:47 +01:00 --- debug: Profiler Library initialized
2008-12-30 13:23:48 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-30 13:23:48 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-30 13:23:48 +01:00 --- debug: Profiler Library initialized
2008-12-30 13:23:48 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-30 13:23:48 +01:00 --- debug: Database Library initialized
2008-12-30 13:42:55 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-30 13:42:55 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-30 13:42:55 +01:00 --- debug: Profiler Library initialized
2008-12-30 13:43:02 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-30 13:43:02 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-30 13:43:02 +01:00 --- debug: Profiler Library initialized
2008-12-30 13:43:03 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-30 13:43:03 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-30 13:43:03 +01:00 --- debug: Profiler Library initialized
2008-12-30 13:43:04 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-30 13:43:04 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-30 13:43:04 +01:00 --- debug: Profiler Library initialized
2008-12-30 13:43:06 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-30 13:43:06 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-30 13:43:06 +01:00 --- debug: Profiler Library initialized
2008-12-30 13:53:05 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-30 13:53:05 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-30 13:53:05 +01:00 --- debug: Profiler Library initialized
2008-12-30 13:53:06 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-30 13:53:06 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-30 13:53:06 +01:00 --- debug: Profiler Library initialized
2008-12-30 13:53:11 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-30 13:53:11 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-30 13:53:11 +01:00 --- debug: Profiler Library initialized
2008-12-30 17:54:34 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-30 17:54:34 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-30 17:54:34 +01:00 --- debug: Profiler Library initialized
2008-12-30 22:08:11 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-30 22:08:11 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-30 22:08:11 +01:00 --- debug: Profiler Library initialized
2008-12-30 22:08:13 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-30 22:08:13 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-30 22:08:13 +01:00 --- debug: Profiler Library initialized
2008-12-30 22:08:14 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-30 22:08:14 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-30 22:08:14 +01:00 --- debug: Profiler Library initialized
2008-12-30 22:08:15 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-30 22:08:15 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-30 22:08:15 +01:00 --- debug: Profiler Library initialized
