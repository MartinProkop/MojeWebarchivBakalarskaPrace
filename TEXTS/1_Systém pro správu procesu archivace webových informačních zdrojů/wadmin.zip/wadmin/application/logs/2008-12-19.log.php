<?php defined('SYSPATH') or die('No direct script access.'); ?>

2008-12-19 00:08:17 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-19 00:08:17 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-19 00:08:17 +01:00 --- debug: Profiler Library initialized
2008-12-19 00:08:17 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-19 00:08:17 +01:00 --- debug: Database Library initialized
2008-12-19 00:08:21 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-19 00:08:21 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-19 00:08:21 +01:00 --- debug: Profiler Library initialized
2008-12-19 00:08:21 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-19 00:08:21 +01:00 --- debug: Database Library initialized
2008-12-19 00:08:52 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-19 00:08:52 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-19 00:08:52 +01:00 --- debug: Profiler Library initialized
2008-12-19 00:08:52 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-19 00:08:52 +01:00 --- debug: Database Library initialized
2008-12-19 00:12:01 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-19 00:12:01 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-19 00:12:01 +01:00 --- debug: Profiler Library initialized
2008-12-19 00:12:01 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-19 00:12:01 +01:00 --- debug: Database Library initialized
2008-12-19 00:17:19 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-19 00:17:19 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-19 00:17:19 +01:00 --- debug: Profiler Library initialized
2008-12-19 00:17:19 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-19 00:17:19 +01:00 --- debug: Database Library initialized
2008-12-19 00:17:52 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-19 00:17:52 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-19 00:17:52 +01:00 --- debug: Profiler Library initialized
2008-12-19 00:17:52 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-19 00:17:52 +01:00 --- debug: Database Library initialized
2008-12-19 00:19:55 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-19 00:19:55 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-19 00:19:55 +01:00 --- debug: Profiler Library initialized
2008-12-19 00:19:55 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-19 00:19:55 +01:00 --- debug: Database Library initialized
2008-12-19 00:21:38 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-19 00:21:38 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-19 00:21:38 +01:00 --- debug: Profiler Library initialized
2008-12-19 00:21:38 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-19 00:21:38 +01:00 --- debug: Database Library initialized
2008-12-19 00:21:45 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-19 00:21:45 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-19 00:21:45 +01:00 --- debug: Profiler Library initialized
2008-12-19 00:21:45 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-19 00:21:45 +01:00 --- debug: Database Library initialized
2008-12-19 00:22:26 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-19 00:22:26 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-19 00:22:26 +01:00 --- debug: Profiler Library initialized
2008-12-19 00:22:26 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-19 00:22:26 +01:00 --- debug: Database Library initialized
2008-12-19 00:28:43 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-19 00:28:43 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-19 00:28:43 +01:00 --- debug: Profiler Library initialized
2008-12-19 00:28:43 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-19 00:28:43 +01:00 --- debug: Database Library initialized
2008-12-19 00:29:02 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-19 00:29:02 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-19 00:29:02 +01:00 --- debug: Profiler Library initialized
2008-12-19 00:29:02 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-19 00:29:02 +01:00 --- debug: Database Library initialized
2008-12-19 00:29:22 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-19 00:29:22 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-19 00:29:22 +01:00 --- debug: Profiler Library initialized
2008-12-19 00:29:22 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-19 00:29:22 +01:00 --- debug: Database Library initialized
2008-12-19 00:30:01 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-19 00:30:01 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-19 00:30:01 +01:00 --- debug: Profiler Library initialized
2008-12-19 00:30:01 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-19 00:30:01 +01:00 --- debug: Database Library initialized
2008-12-19 00:30:15 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-19 00:30:15 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-19 00:30:15 +01:00 --- debug: Profiler Library initialized
2008-12-19 00:30:15 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-19 00:30:15 +01:00 --- debug: Database Library initialized
2008-12-19 00:30:23 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-19 00:30:23 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-19 00:30:23 +01:00 --- debug: Profiler Library initialized
2008-12-19 00:30:23 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-19 00:30:23 +01:00 --- debug: Database Library initialized
2008-12-19 00:30:24 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-19 00:30:24 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-19 00:30:24 +01:00 --- debug: Profiler Library initialized
2008-12-19 00:30:24 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-19 00:30:24 +01:00 --- debug: Database Library initialized
2008-12-19 00:30:32 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-19 00:30:32 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-19 00:30:32 +01:00 --- debug: Profiler Library initialized
2008-12-19 00:30:32 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-19 00:30:32 +01:00 --- debug: Database Library initialized
2008-12-19 00:31:06 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-19 00:31:06 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-19 00:31:06 +01:00 --- debug: Profiler Library initialized
2008-12-19 00:31:06 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-19 00:31:06 +01:00 --- debug: Database Library initialized
2008-12-19 00:31:22 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-19 00:31:22 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-19 00:31:22 +01:00 --- debug: Profiler Library initialized
2008-12-19 00:31:22 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-19 00:31:22 +01:00 --- debug: Database Library initialized
2008-12-19 00:31:34 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-19 00:31:34 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-19 00:31:34 +01:00 --- debug: Profiler Library initialized
2008-12-19 00:31:34 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-19 00:31:34 +01:00 --- debug: Database Library initialized
2008-12-19 12:20:02 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-19 12:20:02 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-19 12:20:02 +01:00 --- debug: Profiler Library initialized
2008-12-19 12:20:02 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-19 12:20:02 +01:00 --- debug: Database Library initialized
2008-12-19 12:20:02 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-19 12:20:02 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-19 12:20:02 +01:00 --- debug: Profiler Library initialized
2008-12-19 12:20:02 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-19 12:20:02 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-19 12:20:02 +01:00 --- debug: Profiler Library initialized
2008-12-19 12:20:02 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-19 12:20:02 +01:00 --- debug: Database Library initialized
2008-12-19 12:20:02 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-19 12:20:02 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-19 12:20:02 +01:00 --- debug: Profiler Library initialized
2008-12-19 12:20:02 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-19 12:20:02 +01:00 --- debug: Database Library initialized
2008-12-19 14:40:02 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-19 14:40:02 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-19 14:40:02 +01:00 --- debug: Profiler Library initialized
2008-12-19 14:40:03 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-19 14:40:03 +01:00 --- debug: Database Library initialized
2008-12-19 14:40:02 +01:00 --- debug: Disable magic_quotes_gpc! It is evil and deprecated: http://php.net/magic_quotes
2008-12-19 14:40:02 +01:00 --- debug: Global GET, POST and COOKIE data sanitized
2008-12-19 14:40:02 +01:00 --- debug: Profiler Library initialized
2008-12-19 14:40:03 +01:00 --- debug: MySQL Database Driver Initialized
2008-12-19 14:40:03 +01:00 --- debug: Database Library initialized
