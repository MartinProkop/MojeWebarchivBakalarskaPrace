<h2>Vyberte tabulku</h2>
<ul>
	<li><a href="<?= url::base() ?>table/view/Resource">Zdroje</a></li>
	<li><a href="<?= url::base() ?>table/view/Contract">Smlouvy</a></li>
	<li><a href="<?= url::base() ?>table/view/Publisher">Vydavatele</a></li>
	<li><a href="<?= url::base() ?>table/view/Contact">Kontakty</a></li>
	<li><a href="<?= url::base() ?>table/view/Url">URL</a></li>
</ul>