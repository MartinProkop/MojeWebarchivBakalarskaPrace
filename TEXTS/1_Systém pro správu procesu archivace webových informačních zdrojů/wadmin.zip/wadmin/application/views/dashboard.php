<div class="dashboard">Ahoj Libore, máš:
<ul>
	<li><a href='<?=url::base()?>rate'><?= $dashboard->to_rate ?> zdrojů k hodnocení</a></li>
	<li><a href='<?=url::base()?>resources'>3 nově hodnocené</a></li>
	<li><a href='<?=url::base()?>rate'>2 zdroje k přehodnocení</a></li>
	<li><a href='<?=url::base()?>catalogue'>3 zdroje ke katalogizaci</a></li>
	<li><a href='<?=url::base()?>addressing'>2 zdroje k oslovení</a></li>
	<li><a href='<?=url::base()?>addressing'>1 zdroj bez odezvy</a></li>
</ul>
</div>