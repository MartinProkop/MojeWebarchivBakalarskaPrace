<h2>Vítejte</h2>

<h2>Důležité informace</h2>

<?= $dashboard ?>

<h2>Statistiky</h2>

<?= $stats ?>

<h2>Vyhledat</h2>

<?= $form ?>

pozn: vyhledává se jméno zdroje, vydavatele a URL