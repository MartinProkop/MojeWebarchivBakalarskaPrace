<?php
$config = array(
	'top_menu' => array(
		'home' , 
		'suggest' , 
		'rate' , 
		'addressing' , 
		'progress' , 
		'catalogue') , 
	
	'ratings_result' => array(
		'1' => 'NE' , 
		'2' => 'ANO' , 
		'3' => 'MOŽNÁ' , 
		'4' => 'TECHNICKÉ NE'))
?>