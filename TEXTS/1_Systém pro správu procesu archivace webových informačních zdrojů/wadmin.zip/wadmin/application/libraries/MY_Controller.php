<?php
// TODO vytvorit automatickou autentizaci a kontrolu uzivatelu
class Controller extends Controller_Core
{
    public function __construct()
    {
        parent::__construct();
    }
}
?>