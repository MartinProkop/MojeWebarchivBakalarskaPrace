<?php defined('SYSPATH') or die('No direct script access.');
/**
 * @package  Cache:Xcache
 *
 * Xcache administrator username.
 */
$config['PHP_AUTH_USER'] = 'kohana';

/**
 * Xcache administrator password.
 */
$config['PHP_AUTH_PW'] = 'kohana';
