<?php defined('SYSPATH') or die('No direct access allowed.');

$lang = array
(
	'driver_not_supported' => '请求的session驱动, %s, 不存在.',
	'driver_implements'    => 'Session必须实现Session_Driver接口.'
);