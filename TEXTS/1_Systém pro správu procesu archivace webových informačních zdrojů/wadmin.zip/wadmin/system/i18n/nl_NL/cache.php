<?php defined('SYSPATH') or die('No direct script access.');

$lang = array
(
	'undefined_group'      => 'De %s groep is niet gedefinieerd in uw configuratie.',
	'extension_not_loaded' => 'De %s PHP extensie moet geladen zijn om deze driver te gebruiken.',
	'unwritable'           => 'De geconfigureerde opslaglocatie, %s, is niet schrijfbaar.',
	'resources'            => 'Het cachen van resources is onmogelijk omdat resources niet geserialized kunnen worden.',
	'driver_error'         => '%s',
);