<?php defined('SYSPATH') or die('No direct script access.');

$lang['query_methods_not_allowed'] = 'Query methods kunnen niet gebruikt worden via ORM';