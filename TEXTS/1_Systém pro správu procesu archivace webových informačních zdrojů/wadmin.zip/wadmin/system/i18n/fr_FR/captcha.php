<?php defined('SYSPATH') or die('No direct access allowed.');

$lang = array 
( 
    'file_not_found' => 'Le fichier spécifié, %s, est introuvable. Merci de vérifier que les fichiers existent, grâce à la fontion file_exists, avant de les utiliser.',
    'requires_GD2'   => 'La librairie Captcha requiert GD2 avec le support FreeType installé. Voir http://php.net/gd_info pour de plus amples renseignements, merci.',
);
