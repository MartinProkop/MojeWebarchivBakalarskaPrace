<?php defined('SYSPATH') or die('No direct script access.');

$lang['method_not_implemented'] = 'La méthode %s n\'est pas implémentée dans le modèle ORM %s.';