<?php defined('SYSPATH') or die('No se permite acceder directamente a este archivo.');

$lang = array
(
	'driver_not_supported' => 'El driver de sessiones, %s, no fue encontrado.',
	'driver_implements'    => 'Los driver de sessiones deben implementar la interfase Session_Driver.'
);