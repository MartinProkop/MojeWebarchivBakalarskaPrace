<?php defined('SYSPATH') or die('No direct script access.');

$lang = array
(
	'invalid_subject'  => 'Nieudana próba podłączenia niewłaściwego podmiotu %s do %s. Podmiot musi dziedziczyć po klasie Event_Subject.',
	'invalid_observer' => 'Nieudana próba podłączenia niewłaściwego obserwatora %s do %s. Obserwator musi dziedziczyć po klasie Event_Observer.',
);