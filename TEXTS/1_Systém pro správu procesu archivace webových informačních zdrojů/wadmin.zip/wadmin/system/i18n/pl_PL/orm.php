<?php defined('SYSPATH') or die('No direct script access.');

$lang['query_methods_not_allowed'] = 'Korzystając z ORM nie można używać zapytań.';
