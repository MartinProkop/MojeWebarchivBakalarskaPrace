<?php defined('SYSPATH') or die('No direct access allowed.');

$lang = array
(
	'general_error' => 'Wystąpił nieznany błąd podczas wysyłania wiadomości.',
);