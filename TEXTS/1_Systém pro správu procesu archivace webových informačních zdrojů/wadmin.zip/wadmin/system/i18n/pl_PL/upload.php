<?php defined('SYSPATH') or die('No direct access allowed.');

$lang = array
(
	'not_writable'       => 'Nie posiadasz prawa zapisu do docelowego katalogu %s.',
);
