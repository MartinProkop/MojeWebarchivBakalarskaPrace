<?php defined('SYSPATH') or die('No direct script access.');

$lang['query_methods_not_allowed'] = 'Suoria query-kutsuja ei voi käyttää ORM:n kanssa';