<?php defined('SYSPATH') or die('No direct script access.');

$lang = array
(
	'undefined_group'      => 'The %s group is not defined in your configuration.',
	'extension_not_loaded' => 'The %s PHP extension must be loaded to use this driver.',
	'unwritable'           => 'The configured storage location, %s, is not writable.',
	'resources'            => 'Caching of resources is impossible, because resources cannot be serialized.',
	'driver_error'         => '%s',
);