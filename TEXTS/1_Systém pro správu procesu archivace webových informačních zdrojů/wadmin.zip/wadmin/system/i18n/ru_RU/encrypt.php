<?php defined('SYSPATH') or die('No direct access allowed.');

$lang = array
(
	'requires_mcrypt'   => 'Для использования библиотеки Encrypt необходимо включить расширение "mcrypt" в конфигурации PHP.',
	'no_encryption_key' => 'Для использования библиотеки Encrypt необходимо задать ключ шифрования в конфигурационном файле.'
);
