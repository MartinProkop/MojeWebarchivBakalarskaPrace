<?php defined('SYSPATH') or die('No direct script access.');

$lang['query_methods_not_allowed'] = 'Методы запросов не могут быть использованы через ORM';
