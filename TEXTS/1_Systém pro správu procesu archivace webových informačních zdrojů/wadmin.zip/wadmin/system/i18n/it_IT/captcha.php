<?php defined('SYSPATH') or die('No direct script access.'); 

$lang = array
(
	'file_not_found' => 'Il file specificato, %s, non è stato trovato. Verificarne l\'esistenza con <tt>file_exists</tt> prima di usarlo.',
	'requires_GD2'	 => 'La libreria Captcha richiede GD2 con supporto FreeType. Leggere http://php.net/gd_info per maggiori informazioni.',
);
