<?php defined('SYSPATH') or die('No direct script access.');

$lang = array
(
	'query_methods_not_allowed'   => 'Non è consentito l\'uso dei metodi di Query mediante ORM.',
);
