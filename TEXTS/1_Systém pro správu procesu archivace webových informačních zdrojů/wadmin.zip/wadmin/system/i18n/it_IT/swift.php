<?php defined('SYSPATH') or die('No direct script access.'); 

$lang = array
(
	'general_error' => 'Si è verificato un errore durante l\'invio del messaggio di posta elettronica.'
);