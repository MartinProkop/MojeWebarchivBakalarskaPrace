<?php defined('SYSPATH') or die('No direct script access.');

$lang['query_methods_not_allowed'] = 'Query-Methoden können nicht über ORM benutzt werden';