<?php defined('SYSPATH') or die('No direct access allowed.');

$lang = array
(
    'undefined_group' => 'O grupo %s não esta definido na sua configuração de paginação.',
	'page'     => 'página',
	'pages'    => 'páginas',
	'item'     => 'item',
	'items'    => 'itens',
	'of'       => 'de',
	'first'    => 'primeiro',
	'last'     => 'último',
	'previous' => 'anterior',
	'next'     => 'próximo',
);
