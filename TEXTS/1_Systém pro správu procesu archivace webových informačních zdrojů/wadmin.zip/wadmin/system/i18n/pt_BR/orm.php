<?php defined('SYSPATH') or die('No direct script access.');

$lang['query_methods_not_allowed'] = 'Métodos de consulta não podem ser usados atráves de ORM';