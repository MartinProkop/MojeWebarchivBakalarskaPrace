<?php defined('SYSPATH') or die('No direct access allowed.');

$lang = array
(
	'requires_mcrypt'   => 'Para usar a biblioteca Encrypt, mcrypt deve estar habilitada em sua configuação PHP.',
	'no_encryption_key' => 'Para usar a biblioteca Encrypt, você precisa configurar um chave de criptografia no seu arquivo de configuracão.'
);
