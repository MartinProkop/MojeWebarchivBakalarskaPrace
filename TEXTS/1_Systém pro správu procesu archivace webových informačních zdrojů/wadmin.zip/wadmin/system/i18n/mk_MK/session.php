<?php defined('SYSPATH') or die('No direct access allowed.');

$lang = array
(
	'invalid_session_name' => 'session_name, %s, е грешка. Треба да содржи само алфанумерички карактери и мора да е напишана најмалку една буква.',
);