<?php defined('SYSPATH') or die('No direct script access.');

$lang = array
(
	'undefined_group'      => 'Групата %s не е дефинирана во конфигурацијата.',
	'extension_not_loaded' => 'PHP екстензијата %s мора да биде вчитана ако го користите овој драјвер.',
	'unwritable'           => 'Во конфигурираната локација за кеширање, <tt>%s</tt>, не може да се запишува.',
	'resources'            => 'Кеширање на ресурсите е невозможно, бидејќи ресурсите не можат да се серијализираат.',
	'driver_error'         => '%s',
);