<?php defined('SYSPATH') or die('No direct script access.');

$lang = array
(
	'invalid_subject'  => 'Намерата да прикачете невалиден субјект <tt>%s</tt> на <tt>%s</tt> е неуспешна. Субјектите мора да бидат екстензии на класата <tt>Event_Subject</tt>.',
	'invalid_observer' => 'Намерата да прикачете невалиден набљудувач <tt>%s</tt> на <tt>%s</tt> е неуспешна. Набљудувачите мора да бидат екстензии на класата <tt>Event_Observer</tt>.',
);
