<?php defined('SYSPATH') or die('No direct script access.');

$lang['method_not_implemented'] = 'Методата %s не е имплементирана во %s ORM моделот.';
