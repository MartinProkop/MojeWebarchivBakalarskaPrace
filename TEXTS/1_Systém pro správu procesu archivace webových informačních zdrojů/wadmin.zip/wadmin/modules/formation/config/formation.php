<?php
$config['label_prefix'] = 'label_';
?>