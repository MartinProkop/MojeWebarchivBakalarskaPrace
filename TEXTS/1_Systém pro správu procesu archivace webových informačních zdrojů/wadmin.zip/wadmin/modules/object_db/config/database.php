<?php defined('SYSPATH') or die('No direct script access.');

$config['default'] = array
(
	'driver'     => 'mysql',
	'hostname'   => 'localhost',
	'username'   => 'root',
	'password'   => 'r00tdb',
	'database'   => 'object_db_test',
	'charset'    => 'utf8',
	'persistent' => FALSE,
	'escaping'   => TRUE,
	'caching'    => TRUE,
);
