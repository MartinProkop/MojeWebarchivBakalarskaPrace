<?php defined('SYSPATH') or die('No direct script access.');

class Database_Having_Core extends Database_Where {

	// Exactly the same functionality as Database_Where

} // End Database Having