<?php defined('SYSPATH') or die('No direct script access.');

class Role_Model extends Auth_Role_Model {

	// This class can be replaced or extended

} // End Role Model