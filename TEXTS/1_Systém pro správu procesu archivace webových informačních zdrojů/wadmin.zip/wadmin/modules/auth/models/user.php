<?php defined('SYSPATH') or die('No direct script access.');

class User_Model extends Auth_User_Model {
	
	// This class can be replaced or extended
	
} // End User Model