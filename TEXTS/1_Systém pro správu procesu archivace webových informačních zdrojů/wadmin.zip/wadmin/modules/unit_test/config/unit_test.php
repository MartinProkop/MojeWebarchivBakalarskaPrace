<?php defined('SYSPATH') or die('No direct script access.');
/**
 * @package  Unit_Test
 *
 * Default paths to scan for tests.
 */
$config['paths'] = array
(
	MODPATH.'unit_test/tests',
);

/**
 * Set to TRUE if you want to hide passed tests from the report.
 */
$config['hide_passed'] = FALSE;
